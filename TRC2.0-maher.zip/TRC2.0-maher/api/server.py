from flask import Flask, request, jsonify
import joblib
import numpy as np
from flask_cors import CORS


app = Flask(__name__)
CORS(app)

model = joblib.load('model.pkl')

plant_names =[
    "Apple",
    "Banana",
    "Blackgram",
    "ChickPea",
    "Coffee",
    "Coconut",
    "Cotton",
    "Grapes",
    "Jute",
    "KidneyBeans",
    "Lentil",
    "Maize",
    "Mango",
    "MothBeans",
    "Muskmelon",
    "MungBean",
    "Orange",
    "Papaya",
    "PigeonPeas",
    "Pomegranate",
    "Rice",
    "Watermelon"
]

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()  
        features = [
            float(data['nitrogen']),
            float(data['phosphorus']),
            float(data['potassium']),
            float(data['temperature']),
            float(data['humidity']),
            float(data['ph']),
            float(data['rainfall'])
        ]

        prediction = model.predict(np.array([features]))[0]  
        prediction = int(prediction)
        result = {
            "plant": plant_names[prediction],
            "prediction": int(prediction)
        }
        return jsonify(result)  
    
    except Exception as e:
        return jsonify({"error": str(e)}), 400  

if __name__ == '__main__':
    app.run(debug=True)