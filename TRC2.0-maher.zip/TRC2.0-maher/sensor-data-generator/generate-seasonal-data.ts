import fs from 'fs';
import path from 'path';

// Interface for sensor reading
interface SensorReading {
    timestamp: string;
    nitrogen: number;
    phosphorus: number;
    potassium: number;
    temperature: number;
    humidity: number;
    pH_Value: number;
    rainfall: number;
}

// Function to generate realistic agricultural sensor data
function generateSeasonalSensorData() {
    // Define constants for data generation
    const READINGS_PER_DAY = 4;
    const SEASON_MONTHS = 4;

    // Date range for the last season (assuming current year)
    const currentDate = new Date();
    const endDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
    const startDate = new Date(endDate.getFullYear(), endDate.getMonth() - SEASON_MONTHS, 1);

    // Total number of days in the season
    const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24));
    const totalReadings = totalDays * READINGS_PER_DAY;

    // Function to generate a realistic value with seasonal variations
    const generateSeasonalValue = (
        baseValue: number,
        minVariation: number,
        maxVariation: number,
        seasonalTrend: (dayOfSeason: number) => number
    ) => {
        return (dayIndex: number) => {
            const seasonalFactor = seasonalTrend(dayIndex);
            const randomVariation = Math.random() * (maxVariation - minVariation) + minVariation;
            return Number((baseValue + seasonalFactor * randomVariation).toFixed(2));
        };
    };

    // Seasonal trends and value generators
    const sensorGenerators = {
        nitrogen: generateSeasonalValue(50, -10, 10, (day) => Math.sin(day / 30 * Math.PI)),
        phosphorus: generateSeasonalValue(25, -5, 5, (day) => Math.cos(day / 30 * Math.PI)),
        potassium: generateSeasonalValue(40, -8, 8, (day) => Math.sin(day / 30 * Math.PI * 2)),
        temperature: generateSeasonalValue(25, -5, 5, (day) => Math.sin((day / totalDays) * Math.PI * 2)),
        humidity: generateSeasonalValue(60, -15, 15, (day) => Math.cos((day / totalDays) * Math.PI * 2)),
        pH_Value: generateSeasonalValue(6.5, -0.5, 0.5, () => 0),
        rainfall: generateSeasonalValue(50, -20, 20, (day) => Math.sin((day / totalDays) * Math.PI))
    };

    // Generate seasonal sensor data
    const seasonalData: SensorReading[] = [];

    for (let dayIndex = 0; dayIndex < totalDays; dayIndex++) {
        for (let readingIndex = 0; readingIndex < READINGS_PER_DAY; readingIndex++) {
            const currentDate = new Date(startDate.getTime() + dayIndex * 24 * 60 * 60 * 1000);
            currentDate.setHours(readingIndex * 6, 0, 0, 0);

            const reading: SensorReading = {
                timestamp: currentDate.toISOString(),
                nitrogen: sensorGenerators.nitrogen(dayIndex),
                phosphorus: sensorGenerators.phosphorus(dayIndex),
                potassium: sensorGenerators.potassium(dayIndex),
                temperature: sensorGenerators.temperature(dayIndex),
                humidity: sensorGenerators.humidity(dayIndex),
                pH_Value: sensorGenerators.pH_Value(dayIndex),
                rainfall: Math.max(0, sensorGenerators.rainfall(dayIndex)) // Ensure non-negative rainfall
            };

            seasonalData.push(reading);
        }
    }

    return seasonalData;
}

// Generate and save the seasonal sensor data
function saveSeasonalSensorData() {
    const seasonalData = generateSeasonalSensorData();

    // Ensure the data directory exists
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir);
    }

    // Save the data to a JSON file
    const filePath = path.join(dataDir, 'seasonal_sensor_data.json');
    fs.writeFileSync(filePath, JSON.stringify(seasonalData, null, 2));

    console.log(`Seasonal sensor data generated and saved to ${filePath}`);
    console.log(`Total readings: ${seasonalData.length}`);
}

// Run the data generation
saveSeasonalSensorData();