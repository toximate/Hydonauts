/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#4CAF50", // Feuille
        brandWhite: "#E4CDA7", // Beige Blé
        darkBlue: "#8B5E3B", // Brun Terre
        accentYellow: "#F4A900", // Jaune Soleil
        accentBlue: "#5DADE2", // Bleu Ciel
      },

      fontFamily: {
        poppins: ["Poppins", "sans-serif"],
      },

      container: {
        center: true,
        padding: {
          DEFAULT: "1rem",
          sm: "2rem",
          lg: "4rem",
          xl: "5rem",
          "2xl": "6rem",
        },
      },
    },
  },
  plugins: [],
};
