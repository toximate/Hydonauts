# EcoSyn

## Description
Nous proposons une plateforme intuitive et un tableau de bord interactif pour visualiser les données critiques en temps réel, permettant des réponses rapides et efficaces aux risques d'incendie.

## Technologies utilisées
React:
React est une bibliothèque JavaScript utilisée pour créer l'interface utilisateur.
Tailwind CSS:
Tailwind CSS est un framework de styles CSS utilisé pour concevoir un design moderne et responsive.
Firebase (Back-end):
Firebase est utilisé pour gérer la base de données et l'authentification de la plateforme.
### Prérequis
- Node.js 
- npm ou yarn

## Installation
1. Clonez ce dépôt : `git clone https://github.com/ahmeeeeedd/Airsense.git`
2. Allez dans le dossier du projet : `cd Airsense
3. Installez les dépendances : `npm install`
4. Lancez l'application : `npm run dev`

## Auteur
*Ahmed hnana* - [ profil GitHub](https://github.com/ahmeeeeedd)


