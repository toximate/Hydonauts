import { useState } from "react";


export function useDetectDisease() {
    const [response, setResponse] = useState<string>('');
    const [isLoading, setIsLoading] = useState(false);

    const fetchDiseaseDetails = async (image: string) => {


        setResponse('');
        setIsLoading(true);

        try {
            // API call to get detailed explanation
            const response = await fetch('https://1e81-102-159-133-113.ngrok-free.app/disease', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    image: image
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to get detailed explanation');
            }

            const result = await response.json();

            setResponse(result.result);



        } catch (error) {
            console.error('Error getting detailed explanation:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const resetDetection = () => {
        setResponse('');
    };

    return {
        response,
        isLoading,
        fetchDiseaseDetails,
        resetDetection,
    };
}