import { useState } from "react";

// Define Message interface for type safety
interface Message {
    id: number;
    content: string;
    sender: 'user' | 'bot';
}

export function useChat() {
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    const getChatResponse = async (query: string) => {
        // Add user message first
        const userMessage: Message = {
            id: Date.now(),
            content: query,
            sender: 'user'
        };

        setMessages(prevMessages => [...prevMessages, userMessage]);
        setIsLoading(true);

        try {
            // API call to get detailed explanation
            const response = await fetch('http://127.0.0.1:8080/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    query: query
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to get detailed explanation');
            }

            const result = await response.json();

            // Add bot message
            const botMessage: Message = {
                id: Date.now() + 1,
                content: result.response,
                sender: 'bot'
            };

            // Update messages with bot response
            setMessages(prevMessages => [...prevMessages, botMessage]);
        } catch (error) {
            console.error('Error getting detailed explanation:', error);
            // Optionally add an error message
            const errorMessage: Message = {
                id: Date.now(),
                content: 'Sorry, something went wrong.',
                sender: 'bot'
            };
            setMessages(prevMessages => [...prevMessages, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    const resetRecommendation = () => {
        setMessages([]);
    };

    return {
        messages,
        isLoading,
        getChatResponse,
        resetRecommendation,
    };
}