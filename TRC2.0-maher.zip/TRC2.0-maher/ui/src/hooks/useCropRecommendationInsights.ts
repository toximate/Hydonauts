import { useState } from "react";

export interface SoilData {
    nitrogen: number;
    phosphorus: number;
    potassium: number;
    temperature: number;
    humidity: number;
    pH_Value: number;
    rainfall: number;
}



export function useCropRecommendationInsights() {
    const [insights, setInsights] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);



    const getRecommendationInsights = async (metrics: SoilData) => {
        setIsLoading(true);
        try {
            // API call to get detailed explanation
            const response = await fetch('http://127.0.0.1:8080/inference', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    metrics_dict: metrics
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to get detailed explanation');
            }

            const result = await response.json();
            console.log("result", result);

            // Update the recommendation with the explanation
            setInsights(
                result.response || 'No detailed explanation available',
            );
        } catch (error) {
            console.error('Error getting detailed explanation:', error);
            // Don't throw error here to avoid breaking the UI flow when explanation fails
        } finally {
            setIsLoading(false);
        }
    };

    const resetRecommendation = () => {
        setInsights(null);
    };

    return {
        insights,
        isLoading,
        getRecommendationInsights,
        resetRecommendation,
    };
}
