import { useState } from "react";

export interface SoilData {
    nitrogen: number;
    phosphorus: number;
    potassium: number;
    temperature: number;
    humidity: number;
    pH_Value: number; // Note: API expects 'ph'
    rainfall: number;
}

export interface ManualInputData {
    nitrogen: string;
    phosphorus: string;
    potassium: string;
    temperature: string;
    humidity: string;
    pH_Value: string;
    rainfall: string;
}

export interface CropRecommendation {
    crop: string;
    explanation?: string;
    bestPractices?: string;
    url?: string;
    insights?: string;
}

export function useCropRecommendation() {
    const [recommendation, setRecommendation] = useState<CropRecommendation | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [showBestPractices, setShowBestPractices] = useState(false);

    const getRecommendation = async (data: SoilData): Promise<CropRecommendation | null> => {
        setIsLoading(true);

        try {
            // Map the data to match API expectations
            const apiPayload = {
                nitrogen: data.nitrogen,
                phosphorus: data.phosphorus,
                potassium: data.potassium,
                temperature: data.temperature,
                humidity: data.humidity,
                ph: data.pH_Value, // Rename pH_Value to ph for API
                rainfall: data.rainfall
            };

            const response = await fetch('http://127.0.0.1:5000/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(apiPayload),
            });

            if (!response.ok) {
                throw new Error(`API request failed with status: ${response.status}`);
            }

            const result = await response.json();

            const newRecommendation = {
                crop: result.plant || 'Unknown',
            };
            setRecommendation(newRecommendation);
            return newRecommendation;
        } catch (error) {
            console.error("Error fetching crop recommendation:", error);
            throw error;
        } finally {
            setIsLoading(false);
        }
    };

    const getDetailedExplanation = async (cropName: string, metrics: SoilData) => {
        setIsLoading(true);
        try {
            // API call to get detailed explanation
            const response = await fetch('http://127.0.0.1:8080/report', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    plant_name: cropName,
                    metrics: {
                        nitrogen: metrics.nitrogen,
                        phosphorus: metrics.phosphorus,
                        potassium: metrics.potassium,
                        temperature: metrics.temperature,
                        humidity: metrics.humidity,
                        ph: metrics.pH_Value,
                        rainfall: metrics.rainfall
                    }
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to get detailed explanation');
            }

            const result = await response.json();
            // Update the recommendation with the explanation
            setRecommendation(prev => prev ? {
                ...prev,
                explanation: result.explanation || 'No detailed explanation available',
                bestPractices: result.recommendations
            } : null);
        } catch (error) {
            console.error('Error getting detailed explanation:', error);
            // Don't throw error here to avoid breaking the UI flow when explanation fails
        } finally {
            setIsLoading(false);
        }
    };

    const getRecommendationUrl = async (cropName: string) => {
        setIsLoading(true);
        try {
            // API call to get detailed explanation
            const response = await fetch('http://127.0.0.1:8080/url', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    plant_name: cropName,
                    format: "youtube"
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to get detailed explanation');
            }

            const result = await response.json();
            // Update the recommendation with the explanation
            setRecommendation(prev => prev ? {
                ...prev,
                url: result.url || 'No detailed explanation available',
            } : null);
        } catch (error) {
            console.error('Error getting detailed explanation:', error);
            // Don't throw error here to avoid breaking the UI flow when explanation fails
        } finally {
            setIsLoading(false);
        }
    };


    const getRecommendationInsights = async (metrics: SoilData) => {
        setIsLoading(true);
        try {
            // API call to get detailed explanation
            const response = await fetch('http://127.0.0.1:8080/inference', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    metrics_dict: metrics
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to get detailed explanation');
            }

            const result = await response.json();
            console.log("result", result);

            // Update the recommendation with the explanation
            setRecommendation(prev => prev ? {
                ...prev,
                insights: result.response || 'No detailed explanation available',
            } : null);
        } catch (error) {
            console.error('Error getting detailed explanation:', error);
            // Don't throw error here to avoid breaking the UI flow when explanation fails
        } finally {
            setIsLoading(false);
        }
    };

    const resetRecommendation = () => {
        setRecommendation(null);
        setShowBestPractices(false);
    };

    return {
        recommendation,
        isLoading,
        showBestPractices,
        setShowBestPractices,
        getRecommendation,
        getDetailedExplanation,
        getRecommendationUrl,
        getRecommendationInsights,
        resetRecommendation,
    };
}
