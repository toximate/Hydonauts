import React from "react";

const PlacementWaterDrops = ({ grid, setGrid }) => {
  const handleAddWaterDrop = (x, y) => {
    const newGrid = [...grid];
    if (!newGrid[x][y]) newGrid[x][y] = "waterDrop";
    setGrid(newGrid);
  };

  const handleRemoveWaterDrop = (x, y) => {
    const newGrid = [...grid];
    if (newGrid[x][y] === "waterDrop") newGrid[x][y] = null;
    setGrid(newGrid);
  };

  return (
    <div className="space-y-6">
      <div className="p-3 bg-blue-50 border border-blue-100 rounded-lg">
        <p className="text-blue-700 font-medium">
          Click on empty grid cells to place water sensors. Click again to
          remove them.
        </p>
      </div>

      <div className="grid grid-cols-10 gap-1 w-full max-w-md mx-auto bg-white/60 p-4 rounded-lg shadow-inner">
        {grid.map((row, rowIndex) =>
          row.map((cell, cellIndex) => (
            <button
              key={`${rowIndex}-${cellIndex}`}
              className={`aspect-square w-full flex items-center justify-center text-xl border ${
                cell === "waterDrop"
                  ? "bg-blue-100 border-blue-300"
                  : cell
                  ? "bg-gray-200 border-gray-300 cursor-not-allowed"
                  : "bg-gray-50 border-gray-200"
              } rounded transition-all ${
                cell !== "waterDrop" && !cell
                  ? "hover:scale-105 hover:shadow-md"
                  : ""
              }`}
              onClick={() =>
                cell === "waterDrop"
                  ? handleRemoveWaterDrop(rowIndex, cellIndex)
                  : !cell
                  ? handleAddWaterDrop(rowIndex, cellIndex)
                  : null
              }
              disabled={cell && cell !== "waterDrop"}
            >
              {cell === "waterDrop"
                ? "💧"
                : cell === "field"
                ? "🌱"
                : cell === "barn"
                ? "🏠"
                : cell === "fence"
                ? "🚧"
                : cell === "tree"
                ? "🌳"
                : typeof cell === "string" && cell !== "waterDrop"
                ? cell
                : ""}
            </button>
          ))
        )}
      </div>
    </div>
  );
};

export default PlacementWaterDrops;
