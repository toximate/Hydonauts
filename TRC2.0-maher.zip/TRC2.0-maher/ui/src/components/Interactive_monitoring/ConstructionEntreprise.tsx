import React, { useState } from "react";

const ConstructionFarm = ({ grid, setGrid }) => {
  const [currentObject, setCurrentObject] = useState("field");
  const [labelText, setLabelText] = useState("");

  // Add or remove objects from the grid
  const handleAddObject = (x, y) => {
    const newGrid = [...grid];
    if (currentObject === "field") {
      newGrid[x][y] = "field";
    } else if (currentObject === "barn") {
      newGrid[x][y] = "barn";
    } else if (currentObject === "fence") {
      newGrid[x][y] = "fence";
    } else if (currentObject === "tree") {
      newGrid[x][y] = "tree";
    } else if (currentObject === "label" && labelText) {
      newGrid[x][y] = labelText;
      setLabelText("");
    }
    setGrid(newGrid); // Update the grid state locally
  };

  const handleRemoveObject = (x, y) => {
    const newGrid = [...grid];
    newGrid[x][y] = null;
    setGrid(newGrid); // Update the grid state locally
  };

  return (
    <div>
      <div className="flex mb-4">
        <select
          value={currentObject}
          onChange={(e) => setCurrentObject(e.target.value)}
          className="mr-2 p-2 border rounded shadow"
        >
          <option value="field">Champ</option>
          <option value="barn">Grange</option>
          <option value="fence">Clôture</option>
          <option value="tree">Arbre</option>
          <option value="label">Étiquette</option>
        </select>

        {currentObject === "label" && (
          <input
            type="text"
            placeholder="Nommer l'espace"
            value={labelText}
            onChange={(e) => setLabelText(e.target.value)}
            className="p-2 border rounded shadow"
          />
        )}
      </div>

      <div className="grid grid-cols-10 gap-1">
        {grid.map(
          (row, rowIndex) =>
            row &&
            row.map((cell, cellIndex) => (
              <div
                key={`${rowIndex}-${cellIndex}`}
                className={`w-10 h-10 border transition duration-200 ease-in-out flex justify-center items-center cursor-pointer ${
                  cell === "field"
                    ? "bg-green-600"
                    : cell === "barn"
                    ? "bg-red-500"
                    : cell === "fence"
                    ? "bg-brown-400"
                    : cell === "tree"
                    ? "bg-green-700"
                    : currentObject === "label" && !cell
                    ? "bg-yellow-200"
                    : "bg-gray-200"
                } ${!cell ? "hover:bg-gray-300" : ""}`}
                onClick={() =>
                  cell
                    ? handleRemoveObject(rowIndex, cellIndex)
                    : handleAddObject(rowIndex, cellIndex)
                }
                aria-label={cell ? `${cell}` : `Ajouter un ${currentObject}`}
              >
                {cell === "field"
                  ? "🌱"
                  : cell === "barn"
                  ? "🏠"
                  : cell === "fence"
                  ? "🚧"
                  : cell === "tree"
                  ? "🌳"
                  : typeof cell === "string"
                  ? cell
                  : ""}
              </div>
            ))
        )}
      </div>
    </div>
  );
};

export default ConstructionFarm;
