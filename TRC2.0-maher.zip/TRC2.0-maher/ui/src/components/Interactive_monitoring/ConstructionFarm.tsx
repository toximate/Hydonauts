import React, { useState } from "react";

const ConstructionFarm = ({ grid, setGrid }) => {
  const [currentObject, setCurrentObject] = useState("field");
  const [labelText, setLabelText] = useState("");

  // Add or remove objects from the grid
  const handleAddObject = (x, y) => {
    const newGrid = [...grid];
    if (currentObject === "field") {
      newGrid[x][y] = "field";
    } else if (currentObject === "barn") {
      newGrid[x][y] = "barn";
    } else if (currentObject === "fence") {
      newGrid[x][y] = "fence";
    } else if (currentObject === "tree") {
      newGrid[x][y] = "tree";
    } else if (currentObject === "label" && labelText) {
      newGrid[x][y] = labelText;
      setLabelText("");
    }
    setGrid(newGrid); // Update the grid state locally
  };

  const handleRemoveObject = (x, y) => {
    const newGrid = [...grid];
    newGrid[x][y] = null;
    setGrid(newGrid); // Update the grid state locally
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-3 items-center">
        <select
          value={currentObject}
          onChange={(e) => setCurrentObject(e.target.value)}
          className="px-4 py-2 bg-white border border-gray-200 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-300 focus:border-blue-300 outline-none transition-all"
        >
          <option value="field">Field</option>
          <option value="barn">Barn</option>
          <option value="fence">Fence</option>
          <option value="tree">Tree</option>
          <option value="label">Label</option>
        </select>

        {currentObject === "label" && (
          <input
            type="text"
            value={labelText}
            onChange={(e) => setLabelText(e.target.value)}
            placeholder="Enter label text"
            className="px-4 py-2 bg-white border border-gray-200 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-300 focus:border-blue-300 outline-none transition-all"
          />
        )}
      </div>

      <div className="grid grid-cols-10 gap-1 w-full max-w-md mx-auto bg-white/60 p-4 rounded-lg shadow-inner">
        {grid.map(
          (row, rowIndex) =>
            row &&
            row.map((cell, cellIndex) => (
              <button
                key={`${rowIndex}-${cellIndex}`}
                className={`aspect-square w-full flex items-center justify-center text-xl border ${
                  cell
                    ? "bg-blue-100 border-blue-300"
                    : "bg-gray-50 border-gray-200"
                } rounded transition-all hover:scale-105 hover:shadow-md`}
                onClick={() =>
                  cell
                    ? handleRemoveObject(rowIndex, cellIndex)
                    : handleAddObject(rowIndex, cellIndex)
                }
                aria-label={cell ? `${cell}` : `Add a ${currentObject}`}
              >
                {cell === "field"
                  ? "🌱"
                  : cell === "barn"
                  ? "🏠"
                  : cell === "fence"
                  ? "🚧"
                  : cell === "tree"
                  ? "🌳"
                  : typeof cell === "string"
                  ? cell
                  : ""}
              </button>
            ))
        )}
      </div>
    </div>
  );
};

export default ConstructionFarm;
