import React, { useEffect, useState } from "react";

const Visualisation = ({ grid }) => {
  const [waterDropStates, setWaterDropStates] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    const updatedWaterDropStates = grid.map((row) =>
      row.map((cell) => {
        if (cell === "waterDrop") {
          const randomSensorValue = Math.random();
          if (randomSensorValue < 0.3) return "green"; // Healthy water
          else if (randomSensorValue < 0.7) return "yellow"; // Warning
          else return "red"; // Critical
        }
        return null;
      })
    );
    setWaterDropStates(updatedWaterDropStates);
    setLastUpdated(new Date());
  }, [grid]);

  // Count different states
  const countStates = () => {
    let healthy = 0,
      warning = 0,
      critical = 0;

    waterDropStates.forEach((row) => {
      row.forEach((state) => {
        if (state === "green") healthy++;
        if (state === "yellow") warning++;
        if (state === "red") critical++;
      });
    });

    return { healthy, warning, critical };
  };

  const { healthy, warning, critical } = countStates();
  const totalSensors = healthy + warning + critical;

  return (
    <div className="space-y-6">
      <div className="p-4 bg-white/80 border border-gray-200 rounded-lg shadow-sm">
        <div className="mb-3">
          <p className="text-sm text-gray-500">
            Last updated: {lastUpdated.toLocaleTimeString()}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
          <div className="bg-green-50 border border-green-100 p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="font-medium text-green-700">
                Healthy Sensors
              </span>
              <span className="text-xl font-bold text-green-600">
                {healthy}
              </span>
            </div>
            <div className="mt-1 h-2 w-full bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-green-500 rounded-full"
                style={{
                  width: totalSensors
                    ? `${(healthy / totalSensors) * 100}%`
                    : "0%",
                }}
              ></div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-100 p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="font-medium text-yellow-700">
                Warning Sensors
              </span>
              <span className="text-xl font-bold text-yellow-600">
                {warning}
              </span>
            </div>
            <div className="mt-1 h-2 w-full bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-yellow-500 rounded-full"
                style={{
                  width: totalSensors
                    ? `${(warning / totalSensors) * 100}%`
                    : "0%",
                }}
              ></div>
            </div>
          </div>

          <div className="bg-red-50 border border-red-100 p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="font-medium text-red-700">Critical Sensors</span>
              <span className="text-xl font-bold text-red-600">{critical}</span>
            </div>
            <div className="mt-1 h-2 w-full bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-red-500 rounded-full"
                style={{
                  width: totalSensors
                    ? `${(critical / totalSensors) * 100}%`
                    : "0%",
                }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-10 gap-1 w-full max-w-md mx-auto bg-white/60 p-4 rounded-lg shadow-inner">
        {waterDropStates.map((row, rowIndex) =>
          row.map((state, cellIndex) => (
            <div
              key={`${rowIndex}-${cellIndex}`}
              className={`aspect-square w-full flex items-center justify-center text-xl border ${
                state === "green"
                  ? "bg-green-100 border-green-300"
                  : state === "yellow"
                  ? "bg-yellow-100 border-yellow-300"
                  : state === "red"
                  ? "bg-red-100 border-red-300"
                  : grid[rowIndex][cellIndex]
                  ? "bg-gray-200 border-gray-300"
                  : "bg-gray-50 border-gray-200"
              } rounded`}
            >
              {grid[rowIndex][cellIndex] === "waterDrop" && state === "green"
                ? "💧" // Healthy water drop
                : grid[rowIndex][cellIndex] === "waterDrop" &&
                  state === "yellow"
                ? "⚠️" // Warning icon for water drop
                : grid[rowIndex][cellIndex] === "waterDrop" && state === "red"
                ? "🔥" // Critical icon for water drop
                : grid[rowIndex][cellIndex] === "field"
                ? "🌱"
                : grid[rowIndex][cellIndex] === "barn"
                ? "🏠"
                : grid[rowIndex][cellIndex] === "fence"
                ? "🚧"
                : grid[rowIndex][cellIndex] === "tree"
                ? "🌳"
                : typeof grid[rowIndex][cellIndex] === "string" &&
                  grid[rowIndex][cellIndex] !== "waterDrop"
                ? grid[rowIndex][cellIndex]
                : ""}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Visualisation;
