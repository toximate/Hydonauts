import React from "react";

const PlacementWaterDrops = ({ grid, setGrid }) => {
  const handleAddWaterDrop = (x, y) => {
    const newGrid = [...grid];
    if (!newGrid[x][y]) newGrid[x][y] = "waterDrop";
    setGrid(newGrid);
  };

  const handleRemoveWaterDrop = (x, y) => {
    const newGrid = [...grid];
    if (newGrid[x][y] === "waterDrop") newGrid[x][y] = null;
    setGrid(newGrid);
  };

  return (
    <div className="grid grid-cols-10 gap-1">
      {grid.map((row, rowIndex) =>
        row.map((cell, cellIndex) => (
          <div
            key={`${rowIndex}-${cellIndex}`}
            className={`w-10 h-10 border transition duration-200 ease-in-out flex justify-center items-center cursor-pointer ${
              cell === "waterDrop" ? "bg-blue-300" : "bg-gray-200"
            }`}
            onClick={() =>
              cell === "waterDrop"
                ? handleRemoveWaterDrop(rowIndex, cellIndex)
                : handleAddWaterDrop(rowIndex, cellIndex)
            }
          >
            {cell === "waterDrop" ? "💧" : ""}
          </div>
        ))
      )}
    </div>
  );
};

export default PlacementWaterDrops;
