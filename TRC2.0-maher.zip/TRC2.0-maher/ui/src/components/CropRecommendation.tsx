import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "./ui/Cards";
import { Button } from "./ui/Button";
import { Sprout, FileText } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import {
  SoilData,
  ManualInputData,
  useCropRecommendation,
} from "../hooks/useCropRecommendation";
import SensorDataDisplay from "./recommendation/SensorDataDisplay";
import ManualInputForm from "./recommendation/ManualInputForm";
import RecommendationResult from "./recommendation/RecommendationResult";
import CropInsights from "./CropInsights";
import ReportGenerator from "./recommendation/ReportGenerator";

interface CropRecommendationProps {
  currentData?: SoilData | null;
}

const CropRecommendation: React.FC<CropRecommendationProps> = ({
  currentData,
}) => {
  const [activeTab, setActiveTab] = useState("automatic");
  const [manualData, setManualData] = useState<ManualInputData>({
    nitrogen: "",
    phosphorus: "",
    potassium: "",
    temperature: "",
    humidity: "",
    pH_Value: "",
    rainfall: "",
  });
  const [showReportModal, setShowReportModal] = useState(false);

  const {
    recommendation,
    isLoading,
    showBestPractices,
    setShowBestPractices,
    getRecommendation,
    getRecommendationUrl,
    resetRecommendation,
    getDetailedExplanation,
  } = useCropRecommendation();

  const handleManualInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setManualData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleAutomaticRecommendation = async () => {
    if (currentData) {
      try {
        const cropRecommendation = await getRecommendation(currentData);
        if (cropRecommendation) {
          // After getting the crop recommendation, request the detailed explanation
          await getDetailedExplanation(cropRecommendation.crop, currentData);
          await getRecommendationUrl(cropRecommendation.crop);
        }
      } catch (error) {
        alert("Failed to get recommendation. Please try again.");
        console.error("API error:", error);
      }
    }
  };

  const handleManualRecommendation = async () => {
    // Validate all fields are filled
    const isValid = Object.values(manualData).every((val) => val !== "");

    if (!isValid) {
      alert("Please fill all fields to get a crop recommendation");
      return;
    }

    // Convert string values to numbers
    const numericData = Object.entries(manualData).reduce<Partial<SoilData>>(
      (acc, [key, value]) => {
        return {
          ...acc,
          [key]: parseFloat(value),
        };
      },
      {}
    ) as SoilData;

    try {
      const cropRecommendation = await getRecommendation(numericData);
      if (cropRecommendation) {
        // After getting the crop recommendation, request the detailed explanation
        await getDetailedExplanation(cropRecommendation.crop, numericData);
        await getRecommendationUrl(cropRecommendation.crop);
      }
    } catch (error) {
      alert("Failed to get recommendation. Please try again.");
      console.error("API error:", error);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-lg bg-primary/10">
            <Sprout className="h-5 w-5 text-green-600" />
          </div>
          <div>
            <CardTitle className="text-xl">Crop Recommendation</CardTitle>
            <CardDescription>
              Get optimal crop suggestions based on soil and climate data
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {!recommendation ? (
          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="automatic">Automatic</TabsTrigger>
              <TabsTrigger value="manual">Manual Entry</TabsTrigger>
            </TabsList>

            <TabsContent value="automatic" className="space-y-4">
              <div className="text-sm text-muted-foreground">
                Generate a crop recommendation using the current sensor data.
              </div>

              <SensorDataDisplay data={currentData} />

              <Button
                onClick={handleAutomaticRecommendation}
                className="w-full mt-4"
                disabled={!currentData || isLoading}
              >
                {isLoading ? "Processing..." : "Get Recommendation"}
              </Button>
            </TabsContent>

            <TabsContent value="manual" className="space-y-4">
              <ManualInputForm
                manualData={manualData}
                onChange={handleManualInputChange}
                onSubmit={handleManualRecommendation}
                isLoading={isLoading}
              />
            </TabsContent>
          </Tabs>
        ) : (
          <>
            <RecommendationResult
              recommendation={{
                crop: recommendation.crop,
                //   bestPractices: recommendation.bestPractices make a new string array by splitting the string by point
                bestPractices: recommendation.bestPractices
                  ? (recommendation.bestPractices as string).split(".")
                  : [],
                explanation:
                  recommendation.explanation ||
                  "Loading detailed explanation...",
                videoUrl: recommendation.url || "",
              }}
              onReset={resetRecommendation}
              showBestPractices={showBestPractices}
              setShowBestPractices={setShowBestPractices}
            />
            {recommendation.bestPractices &&
              recommendation.explanation &&
              recommendation.url &&
              recommendation.crop && (
                <div className="mt-4 flex justify-end">
                  <Button
                    variant="outline"
                    className="flex items-center gap-2"
                    onClick={() => setShowReportModal(true)}
                  >
                    <FileText size={16} />
                    Generate Report
                  </Button>
                </div>
              )}
            <CropInsights cropName={recommendation.crop} />

            {showReportModal &&
              recommendation.bestPractices &&
              recommendation.explanation &&
              recommendation.url &&
              recommendation.crop && (
                <div className="flex justify-center mt-16">
                  <ReportGenerator
                    recommendation={{
                      crop: recommendation.crop,
                      bestPractices: recommendation.bestPractices
                        ? (recommendation.bestPractices as string).split(".")
                        : [],
                      explanation: recommendation.explanation || "",
                      videoUrl: recommendation.url || "",
                    }}
                    soilData={
                      activeTab === "automatic"
                        ? currentData
                        : (manualData as unknown as SoilData)
                    }
                    onClose={() => setShowReportModal(false)}
                  />
                </div>
              )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default CropRecommendation;
