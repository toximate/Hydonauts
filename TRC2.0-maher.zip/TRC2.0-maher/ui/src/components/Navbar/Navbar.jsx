import { useState } from "react";
import { motion } from "framer-motion";
import { FaCog, FaBars, FaTimes } from "react-icons/fa";
import { Link } from "react-router-dom";
import Logo from "../../assets/logo.png";
import { BiMessageRoundedDetail } from "react-icons/bi";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.header
      initial={{ opacity: 0, y: -100 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6 }}
      className="relative bg-white shadow-md"
    >
      <div className="container mx-auto px-4 py-5 flex items-center justify-between">
        {/* Logo */}
        <div>
          <img src={Logo} alt="Logo" className="w-14" />
        </div>

        <div className="md:hidden">
          <button onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? (
              <FaTimes className="text-gray-600" size={24} />
            ) : (
              <FaBars className="text-gray-600" size={24} />
            )}
          </button>
        </div>

        {/* Desktop Navigation */}
        <ul className="hidden md:flex items-center gap-10 md:text-base text-sm">
          <li>
            <Link
              to="/"
              className="hover:text-primary transition-colors duration-300"
            >
              Main
            </Link>
          </li>
          <li>
            <Link
              to="/Water_management"
              className="hover:text-primary transition-colors duration-300"
            >
              IA farmer{" "}
            </Link>
          </li>
          <li>
            <Link
              to="/Virtual_market"
              className="hover:text-primary transition-colors duration-300"
            >
              IA controller
            </Link>
          </li>
          <li>
            <Link
              to="/manage-water"
              className="hover:text-primary transition-colors duration-300"
            >
              Water Management
            </Link>
          </li>
          <li>
            <Link
              to="/Interactive"
              className="hover:text-primary transition-colors duration-300"
            >
              Interactive Monitoring
            </Link>
          </li>
          <li>
            <Link
              to="/Dashboard"
              className="hover:text-primary transition-colors duration-300"
            >
              Weather Dashboard
            </Link>
          </li>
          <li>
            <Link
              to="/blockchain-market"
              className="hover:text-primary transition-colors duration-300"
            >
              Blockchain Market
            </Link>
          </li>
          {/* <li>
            <Link
              to="/Notification"
              className="hover:text-primary transition-colors duration-300"
            >
              Alert Notifications
            </Link>
          </li> */}
        </ul>

        {/* Icons */}
        <div className="hidden md:flex items-center space-x-4">
          <Link to="/ContactUs">
            <BiMessageRoundedDetail className="text-gray-400 text-2xl hover:text-primary transition-colors duration-300" />
          </Link>
          <Link to="/Paramétre" aria-label="Go to Settings">
            <FaCog
              className="text-gray-600 hover:text-primary cursor-pointer"
              size={24}
            />
          </Link>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="md:hidden absolute top-16 left-0 w-full bg-white shadow-md"
        >
          <ul className="flex flex-col items-center gap-6 py-5">
            <li>
              <Link
                to="/"
                className="hover:text-primary transition-colors duration-300"
                onClick={() => setIsOpen(false)}
              >
                Main
              </Link>
            </li>
            <li>
              <Link
                to="/Dashboard"
                className="hover:text-primary transition-colors duration-300"
                onClick={() => setIsOpen(false)}
              >
                Dashboard
              </Link>
            </li>
            <li>
              <Link
                to="/Water_management"
                className="hover:text-primary transition-colors duration-300"
                onClick={() => setIsOpen(false)}
              >
                Water management
              </Link>
            </li>
            <li>
              <Link
                to="/Interactive"
                className="hover:text-primary transition-colors duration-300"
                onClick={() => setIsOpen(false)}
              >
                Interactive Monitoring
              </Link>
            </li>
            <li>
              <Link
                to="/Virtual_market"
                className="hover:text-primary transition-colors duration-300"
                onClick={() => setIsOpen(false)}
              >
                Virtual Market
              </Link>
            </li>
            <li>
              <Link
                to="/blockchain-market"
                className="hover:text-primary transition-colors duration-300"
                onClick={() => setIsOpen(false)}
              >
                Blockchain Market
              </Link>
            </li>
            {/* <li>
              <Link
                to="/Notification"
                className="hover:text-primary transition-colors duration-300"
                onClick={() => setIsOpen(false)}
              >
                Alert Notifications
              </Link>
            </li> */}
          </ul>

          {/* Icons in Mobile Menu */}
          <div className="flex justify-center space-x-6 py-3">
            <Link to="/ContactUs" onClick={() => setIsOpen(false)}>
              <BiMessageRoundedDetail className="text-gray-400 text-2xl hover:text-primary transition-colors duration-300" />
            </Link>
            <Link
              to="/Paramétre"
              aria-label="Go to Settings"
              onClick={() => setIsOpen(false)}
            >
              <FaCog
                className="text-gray-600 hover:text-primary cursor-pointer"
                size={24}
              />
            </Link>
          </div>
        </motion.div>
      )}
    </motion.header>
  );
};

export default Navbar;
