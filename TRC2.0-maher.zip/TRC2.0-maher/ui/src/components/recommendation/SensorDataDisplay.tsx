import React from "react";
import { SoilData } from "../../hooks/useCropRecommendation";

interface SensorDataDisplayProps {
  data: SoilData | null | undefined;
}

const SensorDataDisplay: React.FC<SensorDataDisplayProps> = ({ data }) => {
  if (!data) {
    return (
      <div className="text-yellow-600 text-sm">
        No current data available. Please wait for sensor readings.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 mt-2">
      <div className="flex justify-between text-sm">
        <span>Nitrogen:</span>{" "}
        <span className="font-medium">{data.nitrogen.toFixed(2)} mg/kg</span>
      </div>
      <div className="flex justify-between text-sm">
        <span>Phosphorus:</span>{" "}
        <span className="font-medium">{data.phosphorus.toFixed(2)} mg/kg</span>
      </div>
      <div className="flex justify-between text-sm">
        <span>Potassium:</span>{" "}
        <span className="font-medium">{data.potassium.toFixed(2)} mg/kg</span>
      </div>
      <div className="flex justify-between text-sm">
        <span>Temperature:</span>{" "}
        <span className="font-medium">{data.temperature.toFixed(2)} °C</span>
      </div>
      <div className="flex justify-between text-sm">
        <span>Humidity:</span>{" "}
        <span className="font-medium">{data.humidity.toFixed(2)} %</span>
      </div>
      <div className="flex justify-between text-sm">
        <span>pH Value:</span>{" "}
        <span className="font-medium">{data.pH_Value.toFixed(2)}</span>
      </div>
      <div className="flex justify-between text-sm">
        <span>Rainfall:</span>{" "}
        <span className="font-medium">{data.rainfall.toFixed(2)} mm</span>
      </div>
    </div>
  );
};

export default SensorDataDisplay;
