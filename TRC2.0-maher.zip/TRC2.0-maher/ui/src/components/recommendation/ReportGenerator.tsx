import React, { useState } from "react";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  PDFDownloadLink,
  Font,
} from "@react-pdf/renderer";
import { SoilData } from "../../hooks/useCropRecommendation";
import { Button } from "../ui/Button";
import { Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@radix-ui/react-dialog";
import { DialogHeader } from "../ui/dialog";

interface RecommendationData {
  crop: string;
  bestPractices: string[];
  explanation: string;
  videoUrl: string;
}

interface ReportGeneratorProps {
  recommendation: RecommendationData;
  soilData: SoilData | null | undefined;
  onClose: () => void;
}

// Register fonts
Font.register({
  family: "Roboto",
  fonts: [
    {
      src: "https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-regular-webfont.ttf",
      fontWeight: "normal",
    },
    {
      src: "https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-bold-webfont.ttf",
      fontWeight: "bold",
    },
  ],
});

// Define styles for PDF
const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    backgroundColor: "#ffffff",
    padding: 30,
    fontFamily: "Roboto",
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: "center",
    fontWeight: "bold",
    color: "#2B7A0B",
  },
  section: {
    margin: 10,
    padding: 10,
    flexGrow: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
    color: "#2B7A0B",
  },
  subtitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginTop: 15,
    marginBottom: 5,
  },
  text: {
    fontSize: 12,
    marginBottom: 5,
  },
  table: {
    display: "flex",
    width: "auto",
    borderStyle: "solid",
    borderWidth: 1,
    borderColor: "#bfbfbf",
    marginBottom: 15,
  },
  tableRow: {
    flexDirection: "row",
  },
  tableHeaderCell: {
    backgroundColor: "#f0f0f0",
    fontWeight: "bold",
    fontSize: 12,
    padding: 5,
    borderWidth: 1,
    borderColor: "#bfbfbf",
    width: "50%",
  },
  tableCell: {
    fontSize: 12,
    padding: 5,
    borderWidth: 1,
    borderColor: "#bfbfbf",
    width: "50%",
  },
  listItem: {
    fontSize: 12,
    marginBottom: 5,
  },
  footer: {
    fontSize: 10,
    marginTop: 30,
    textAlign: "center",
    color: "grey",
  },
  divider: {
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
    marginVertical: 15,
  },
});

// PDF Document Component
const CropRecommendationPDF = ({
  recommendation,
  soilData,
}: {
  recommendation: RecommendationData;
  soilData: SoilData | null | undefined;
}) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <Text style={styles.header}>Crop Recommendation Report</Text>

      <View style={styles.section}>
        <Text style={styles.title}>
          Recommended Crop: {recommendation.crop}
        </Text>

        <View style={styles.divider} />

        <Text style={styles.subtitle}>Soil and Environment Data:</Text>
        {soilData && (
          <View style={styles.table}>
            {Object.entries(soilData).map(([key, value], index) => (
              <View style={styles.tableRow} key={index}>
                <Text style={styles.tableHeaderCell}>
                  {key.charAt(0).toUpperCase() + key.slice(1).replace("_", " ")}
                </Text>
                <Text style={styles.tableCell}>
                  {value}
                  {key === "temperature"
                    ? "°C"
                    : key === "humidity"
                    ? "%"
                    : key === "rainfall"
                    ? "mm"
                    : ""}
                </Text>
              </View>
            ))}
          </View>
        )}

        <View style={styles.divider} />

        <Text style={styles.subtitle}>Detailed Explanation:</Text>
        <Text style={styles.text}>{recommendation.explanation}</Text>

        <View style={styles.divider} />

        <Text style={styles.subtitle}>Best Practices:</Text>
        {recommendation.bestPractices
          .filter((practice) => practice.trim())
          .map((practice, index) => (
            <Text key={index} style={styles.listItem}>
              • {practice.trim()}
            </Text>
          ))}

        {recommendation.videoUrl && (
          <>
            <View style={styles.divider} />
            <Text style={styles.subtitle}>Additional Resources:</Text>
            <Text style={styles.text}>
              Video Reference: {recommendation.videoUrl}
            </Text>
          </>
        )}
      </View>

      <Text style={styles.footer}>
        Generated on {new Date().toLocaleDateString()}
      </Text>
    </Page>
  </Document>
);

const ReportGenerator: React.FC<ReportGeneratorProps> = ({
  recommendation,
  soilData,
  onClose,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);

  // Filename for the downloaded PDF
  const filename = `${recommendation.crop
    .toLowerCase()
    .replace(/\s+/g, "-")}-recommendation-${
    new Date().toISOString().split("T")[0]
  }.pdf`;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Generate Report</DialogTitle>
        </DialogHeader>

        <div className="py-4">
          <p className="text-sm text-muted-foreground mb-4">
            Generate a comprehensive PDF report with all the recommendation
            details and soil data.
          </p>

          <div className="flex justify-center mt-6">
            <PDFDownloadLink
              document={
                <CropRecommendationPDF
                  recommendation={recommendation}
                  soilData={soilData}
                />
              }
              fileName={filename}
              className="w-full"
            >
              {({ loading, error }) => (
                <Button
                  className="w-full"
                  disabled={loading || isGenerating}
                  onClick={() => {
                    setIsGenerating(true);
                    // Allow time to see the loading state for better UX
                    setTimeout(() => setIsGenerating(false), 1000);
                  }}
                >
                  {loading || isGenerating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Preparing PDF...
                    </>
                  ) : (
                    "Download PDF Report"
                  )}
                </Button>
              )}
            </PDFDownloadLink>
          </div>

          <div className="flex justify-end mt-4">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ReportGenerator;
