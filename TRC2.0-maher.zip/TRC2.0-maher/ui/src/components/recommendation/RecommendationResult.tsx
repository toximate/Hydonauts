import React from "react";
import { Button } from "../ui/Button";
import { Leaf } from "lucide-react";
import CropBestPractices from "../CropBestPractices";
import { CropRecommendation } from "../../data/mockCropData";
import MarkdownRenderer from "../ui/MarkdownRenderer";

interface RecommendationResultProps {
  recommendation: CropRecommendation;
  onReset: () => void;
  showBestPractices: boolean;
  setShowBestPractices: (show: boolean) => void;
}

const RecommendationResult: React.FC<RecommendationResultProps> = ({
  recommendation,
  onReset,
  showBestPractices,
  setShowBestPractices,
}) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-center flex-col space-y-2">
        <div className="p-3 bg-green-100 rounded-full">
          <Leaf className="h-8 w-8 text-green-600" />
        </div>
        <h3 className="text-2xl font-bold text-center">
          {recommendation.crop}
        </h3>
        <p className="text-sm text-muted-foreground text-center">
          Recommended Crop
        </p>
      </div>

      <div className="bg-gray-50 p-4 rounded-lg">
        <h4 className="font-medium mb-2">Why this crop?</h4>
        <p className="text-sm text-muted-foreground">
          <MarkdownRenderer
            content={`
              MungBean Adaptability Assessment: Severely Deficient Conditions

The given soil and environmental metrics make MungBean cultivation extremely unsuitable, with near-zero chance of success. All parameters are marked "None," indicating a severely deficient environment conflicting with MungBean’s needs.  

### Key Deficiencies:  
1. **Nutrients (NPK: 0 ppm)** – Essential for growth. Nitrogen fixation requires initial N, while P and K are critical for root development, energy transfer, and stress tolerance. Total absence disrupts basic cellular functions.  
2. **Temperature: None °C** – Far below MungBean’s optimal range (25–35°C), halting metabolism and germination.  
3. **Humidity: None %** – Extreme dryness causes rapid water loss, worsening drought effects.  
4. **pH: None** – Unmeasurable pH suggests extreme acidity/alkalinity, blocking nutrient uptake and risking toxicity.  
5. **Rainfall: None mm** – Severe drought prevents photosynthesis, nutrient transport, and cell function.  

### Interaction of Factors:  
Nutrient lack weakens plants, increasing vulnerability to temperature and drought stress. No rainfall and humidity worsen deficiencies, while extreme pH further limits nutrient access.  

### Conclusion:  
The conditions are entirely hostile—lacking nutrients, water, and suitable temperature. Cultivation would fail without major interventions like fertilization, irrigation, and climate control.`}
            className="prose prose-sm max-w-none"
          />
        </p>
      </div>

      <Button variant="outline" onClick={onReset} className="w-full">
        Try Another Recommendation
      </Button>

      <CropBestPractices
        crop={recommendation.crop}
        bestPractices={[
          "Use no-till farming to prevent erosion",
          "Amend soil with compost & aged manure",
          "Plant drought-tolerant cover crops",
          "Install drip irrigation for efficiency",
          "Harvest rainwater via swales/rain gardens",
          "Inoculate seeds with Rhizobium bacteria",
          "Apply mycorrhizal fungi for phosphorus",
          "Enhance soil with biochar",
          "Introduce earthworms for aeration",
          "Adjust pH naturally (lime/sulfur)",
          "Monitor soil health regularly",
        ]}
        videoUrl={recommendation.videoUrl}
        showBestPractices={showBestPractices}
        setShowBestPractices={setShowBestPractices}
      />
    </div>
  );
};

export default RecommendationResult;
