import React from "react";
import { Button } from "../ui/Button";
import { Input } from "../ui/input";
import { Label } from "@radix-ui/react-label";
import { ManualInputData } from "../../hooks/useCropRecommendation";

interface ManualInputFormProps {
  manualData: ManualInputData;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSubmit: () => void;
  isLoading: boolean;
}

const ManualInputForm: React.FC<ManualInputFormProps> = ({
  manualData,
  onChange,
  onSubmit,
  isLoading,
}) => {
  return (
    <>
      <div className="text-sm text-muted-foreground mb-4">
        Enter soil parameters manually to get a custom crop recommendation.
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="nitrogen">Nitrogen (mg/kg)</Label>
          <Input
            id="nitrogen"
            name="nitrogen"
            placeholder="e.g. 50"
            value={manualData.nitrogen}
            onChange={onChange}
            type="number"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="phosphorus">Phosphorus (mg/kg)</Label>
          <Input
            id="phosphorus"
            name="phosphorus"
            placeholder="e.g. 25"
            value={manualData.phosphorus}
            onChange={onChange}
            type="number"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="potassium">Potassium (mg/kg)</Label>
          <Input
            id="potassium"
            name="potassium"
            placeholder="e.g. 60"
            value={manualData.potassium}
            onChange={onChange}
            type="number"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="temperature">Temperature (°C)</Label>
          <Input
            id="temperature"
            name="temperature"
            placeholder="e.g. 25"
            value={manualData.temperature}
            onChange={onChange}
            type="number"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="humidity">Humidity (%)</Label>
          <Input
            id="humidity"
            name="humidity"
            placeholder="e.g. 65"
            value={manualData.humidity}
            onChange={onChange}
            type="number"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="pH_Value">pH Value</Label>
          <Input
            id="pH_Value"
            name="pH_Value"
            placeholder="e.g. 6.5"
            value={manualData.pH_Value}
            onChange={onChange}
            type="number"
            step="0.1"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="rainfall">Rainfall (mm)</Label>
          <Input
            id="rainfall"
            name="rainfall"
            placeholder="e.g. 30"
            value={manualData.rainfall}
            onChange={onChange}
            type="number"
          />
        </div>
      </div>

      <Button onClick={onSubmit} className="w-full mt-4" disabled={isLoading}>
        {isLoading ? "Processing..." : "Get Recommendation"}
      </Button>
    </>
  );
};

export default ManualInputForm;
