import React from "react";
import { motion } from "framer-motion";
import {
  FaSeedling,
  FaCloudSun,
  FaWater,
  FaSun,
  FaTemperatureHigh,
} from "react-icons/fa";

const optionList = [
  {
    id: 1,
    name: "Soil Moisture",
    icon: <FaWater size={24} />,
    color: "#4CAF50",
    description: "Monitor soil water content for optimal irrigation",
  },
  {
    id: 2,
    name: "Sunlight",
    icon: <FaSun size={24} />,
    color: "#FFEB3B",
    description: "Track light exposure for plant photosynthesis",
  },
  {
    id: 3,
    name: "Temperature",
    icon: <FaTemperatureHigh size={24} />,
    color: "#FF5722",
    description: "Measure ambient and soil temperature conditions",
  },
  {
    id: 4,
    name: "Air Quality",
    icon: <FaCloudSun size={24} />,
    color: "#8EACCD",
    description: "Analyze atmospheric conditions affecting crops",
  },
  {
    id: 5,
    name: "Soil Health",
    icon: <FaSeedling size={24} />,
    color: "#8BC34A",
    description: "Assess nutrient levels and soil composition",
  },
];

const OptionCard = () => {
  return (
    <div className="container py-20 px-4">
      <div className="space-y-4 text-center max-w-2xl mx-auto mb-12">
        <h3 className="uppercase font-semibold text-[#4CAF50] tracking-wider text-sm">
          Detected Options
        </h3>
        <h2 className="font-bold text-3xl md:text-4xl text-darkBlue">
          Monitoring Agricultural Conditions
        </h2>
        <p className="text-gray-600 mt-4 mb-6">
          Our advanced sensors detect and monitor key environmental factors to
          optimize your farming operations
        </p>
        <div className="w-24 h-1 bg-[#4CAF50] mx-auto mt-4"></div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {optionList.map((option) => {
          return (
            <motion.div
              key={option.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{
                type: "spring",
                stiffness: 100,
                delay: option.id * 0.1,
              }}
              whileHover={{
                scale: 1.03,
                boxShadow:
                  "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
              }}
              className="bg-white rounded-xl border border-[#4CAF50]/20 p-6 flex flex-col transition-all duration-300 cursor-pointer shadow-md"
            >
              <div
                style={{
                  color: option.color,
                  backgroundColor: option.color + "20",
                }}
                className="w-16 h-16 rounded-full flex justify-center items-center mb-4"
              >
                {option.icon}
              </div>
              <h3 className="text-xl font-semibold text-darkBlue mb-2">
                {option.name}
              </h3>
              <div
                style={{ backgroundColor: option.color + "40" }}
                className="w-12 h-1 rounded-full mb-3"
              ></div>
              <p className="text-gray-600">{option.description}</p>
              <div className="mt-4 pt-2 border-t border-gray-100">
                <button
                  style={{ color: option.color }}
                  className="flex items-center text-sm font-medium hover:underline"
                >
                  View Details
                  <svg
                    className="w-4 h-4 ml-1"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M9 5l7 7-7 7"
                    ></path>
                  </svg>
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default OptionCard;
