import React from "react";
import HeroImage from "../../assets/home.png";
import { SlideUp } from "../../utility/animation";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const Hero = () => {
  return (
    <section className="py-12 md:py-20 px-4">
      <div className="bg-white shadow-xl rounded-3xl container grid grid-cols-1 md:grid-cols-2 gap-8 min-h-[650px] overflow-hidden">
        <div className="flex flex-col justify-center xl:pr-40 px-6 md:px-12">
          <div className="mt-24 mb-10 md:mt-0 md:mb-0 space-y-6 text-center md:text-left">
            <motion.h1
              variants={SlideUp(0.2)}
              whileInView={"animate"}
              initial="initial"
              className="text-4xl md:text-5xl font-bold text-darkBlue bg-gradient-to-r from-darkBlue to-[#4CAF50] bg-clip-text text-transparent"
            >
              Revolutionize Agriculture <br /> with Smart Technology
            </motion.h1>
            <motion.p
              variants={SlideUp(0.4)}
              whileInView={"animate"}
              initial="initial"
              className="text-lg text-gray-600 mt-4 leading-relaxed"
            >
              Harness the power of IoT and data to optimize crop production and
              ensure sustainability in farming.
            </motion.p>
            <motion.div
              variants={SlideUp(0.6)}
              whileInView={"animate"}
              initial="initial"
              className="mt-8"
            >
              <Link to="/Dashboard">
                <button className="bg-gradient-to-r from-[#4CAF50] to-[#2E7D32] text-white px-8 py-4 rounded-full font-bold hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                  Start Farming Smart
                </button>
              </Link>
            </motion.div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="flex items-center justify-center relative overflow-hidden"
        >
          <div className="absolute w-full h-full bg-gradient-to-br from-[#4CAF50]/10 to-transparent rounded-l-full z-0" />
          <img
            src={HeroImage}
            alt="Smart Agriculture"
            className="w-full h-auto max-w-4xl mx-auto relative z-10 transform hover:scale-105 transition-transform duration-500"
          />
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
