import React from "react";
import Logo from "../../assets/logo.png"; 
import { FaFacebook, FaInstagram, FaLinkedin } from "react-icons/fa";
import { motion } from "framer-motion";

const Footer = () => {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-brandWhite" // Couleur de fond adaptée à l'agriculture intelligente
    >
      <div className="container py-20 flex flex-col md:flex-row md:items-center justify-between gap-10">
        <div className="space-y-4">
          <img src={Logo} alt="Company Logo" className="w-40" />
          <p className="text-gray-600 xl:max-w-[400px]">
            Our mission is to provide sustainable and innovative solutions to
            monitor environmental conditions for better agricultural practices.
            With our advanced sensors, we ensure real-time monitoring of soil
            moisture, sunlight, temperature, and air quality to optimize
            farming.
          </p>
        </div>
        <div className="flex space-x-6 text-3xl">
          <FaFacebook className="hover:text-[#4CAF50] duration-200 cursor-pointer" />
          <FaInstagram className="hover:text-[#4CAF50] duration-200 cursor-pointer" />
          <FaLinkedin className="hover:text-[#4CAF50] duration-200 cursor-pointer" />
        </div>
      </div>
      <div className="py-4 text-center border-t border-[#4CAF50]">
        {" "}
        {/* Utilisation du vert pour le border */}
        <p className="text-sm text-gray-500">
          © {new Date().getFullYear()} Hydronauts. All rights reserved.{" "}
          {/* Modification du nom pour le thème agricole */}
        </p>
      </div>
    </motion.footer>
  );
};

export default Footer;
