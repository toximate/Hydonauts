import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/Cards";
import MarkdownRenderer from "./ui/MarkdownRenderer";
import { useCropRecommendation } from "../hooks/useCropRecommendation";
import { useCropRecommendationInsights } from "../hooks/useCropRecommendationInsights";

export type SensorData = {
  timestamp: string;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  temperature: number;
  humidity: number;
  pH_Value: number;
  rainfall: number;
};

interface SoilInsightCardProps {
  realTimeData: SensorData | null;
  onClose: () => void;
}

const SoilInsightCard: React.FC<SoilInsightCardProps> = ({
  realTimeData,
  onClose,
}) => {
  const { insights, isLoading, getRecommendationInsights } =
    useCropRecommendationInsights();

  const [showInsights, setShowInsights] = useState(false);

  const generateInsights = async () => {
    if (!realTimeData) return;

    // Simulate API call or processing delay
    await getRecommendationInsights(realTimeData);

    setShowInsights(true);
  };

  return (
    <>
      <div className="flex justify-center mt-6">
        <button
          onClick={generateInsights}
          disabled={isLoading}
          className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors flex items-center space-x-2"
        >
          {isLoading ? (
            <>
              <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
              <span>Generating...</span>
            </>
          ) : (
            <span>Generate Insights</span>
          )}
        </button>
      </div>

      {showInsights && insights && (
        <div className="mt-6">
          <Card className="bg-white/50 backdrop-blur-sm border border-gray-200">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-xl">
                  Soil and Environment Insights
                </CardTitle>
                <button
                  onClick={() => {
                    setShowInsights(false);
                    onClose();
                  }}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>
            </CardHeader>
            <CardContent>
              <MarkdownRenderer
                content={insights || ""}
                className="prose prose-sm max-w-none"
              />
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
};

export default SoilInsightCard;
