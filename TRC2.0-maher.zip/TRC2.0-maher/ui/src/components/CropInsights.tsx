import React, { useState } from "react";
import { cropDataMap, getCropData } from "../utility/cropDataMap";

const CropInsights = ({ cropName }: { cropName: string }) => {
  const [selectedCrop, setSelectedCrop] = useState<string>(cropName);
  const cropData = getCropData(selectedCrop);

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-2xl shadow-lg text-center">
      <h2 className="text-xl font-bold text-gray-800">
        Oxygen Production Insights
      </h2>
      <div className="mt-4 p-4 bg-gray-100 rounded-lg">
        <p className="text-lg font-semibold">{selectedCrop}</p>
        {cropData ? (
          <>
            <p className="text-gray-700">
              CO₂ Absorbed: {cropData.co2Absorbed} kg
            </p>
            <p className="text-gray-700">
              O₂ Released: {cropData.o2Released} kg
            </p>
          </>
        ) : (
          <p className="text-gray-700">Data not available</p>
        )}
      </div>
    </div>
  );
};

export default CropInsights;
