import React, { useState, useRef, useEffect } from "react";
import { Send, X, MessageCircle, Trash2 } from "lucide-react";
import { useChat } from "../hooks/useChat";

// Define Message interface for type safety
interface Message {
  id: number;
  content: string;
  sender: "user" | "bot";
}

const GeminiChat: React.FC = () => {
  const [input, setInput] = useState("");
  const [isVisible, setIsVisible] = useState(false);
  const { messages, isLoading, resetRecommendation, getChatResponse } =
    useChat();
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (input.trim() && !isLoading) {
      getChatResponse(input);
      setInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  const handleOpen = () => {
    setIsVisible(true);
  };

  if (!isVisible) {
    return (
      <button
        onClick={handleOpen}
        className="fixed bottom-4 right-4 bg-[#93c47d] text-white p-3 rounded-full shadow-lg hover:bg-[#7bac64] transition-all"
        title="Open Chat"
      >
        <MessageCircle size={24} />
      </button>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 w-96 bg-white shadow-lg rounded-lg border border-[#d9ead3] z-50">
      {/* Chat Header */}
      <div className="flex justify-between items-center p-4 border-b bg-[#d9ead3]">
        <h2 className="text-lg font-semibold text-[#38761d]">Gemini Chatbot</h2>
        <div className="flex gap-2">
          <button
            onClick={resetRecommendation}
            className="text-[#66a14c] hover:text-[#38761d]"
            title="Clear Chat"
          >
            <Trash2 size={20} />
          </button>
          <button
            onClick={handleClose}
            className="text-[#6aa84f] hover:text-[#38761d]"
            title="Close Chat"
          >
            <X size={20} />
          </button>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="h-96 overflow-y-auto p-4 space-y-4 bg-[#f8fbf6]">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${
              message.sender === "user" ? "justify-end" : "justify-start"
            }`}
          >
            <div
              className={`max-w-[80%] p-3 rounded-lg ${
                message.sender === "user"
                  ? "bg-[#93c47d] text-white"
                  : "bg-[#d9ead3] text-[#274e13]"
              }`}
            >
              {message.content}
            </div>
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>

      {/* Input Area */}
      <div className="flex p-4 border-t bg-white">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type a message..."
          disabled={isLoading}
          className="flex-grow p-2 border rounded-l-lg focus:outline-none focus:ring-2 focus:ring-[#93c47d] border-[#d9ead3]"
        />
        <button
          onClick={handleSendMessage}
          disabled={isLoading || !input.trim()}
          className="bg-[#93c47d] text-white p-2 rounded-r-lg hover:bg-[#7bac64] disabled:opacity-50"
        >
          <Send size={20} />
        </button>
      </div>
    </div>
  );
};

export default GeminiChat;
