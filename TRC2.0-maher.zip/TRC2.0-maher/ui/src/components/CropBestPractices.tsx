import React from "react";
import { Button } from "./ui/Button";
import { Sprout, FileInput } from "lucide-react";

interface CropBestPracticesProps {
  crop: string;
  bestPractices: string[];
  videoUrl: string;
  showBestPractices: boolean;
  setShowBestPractices: (show: boolean) => void;
}

const CropBestPractices: React.FC<CropBestPracticesProps> = ({
  crop,
  bestPractices,
  videoUrl,
  showBestPractices,
  setShowBestPractices,
}) => {
  // Extract YouTube video ID from the URL with safety checks
  const getYoutubeVideoId = (url: string | null | undefined): string => {
    if (!url || typeof url !== "string") return "";

    try {
      const regExp =
        /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
      const match = url.match(regExp);
      return match && match[2].length === 11 ? match[2] : "";
    } catch (error) {
      console.error("Error parsing YouTube URL:", error);
      return "";
    }
  };

  console.log("videoUrl", videoUrl);

  const youtubeEmbedUrl = `https://www.youtube.com/embed/${getYoutubeVideoId(
    videoUrl[0]
  )}`;

  return (
    <>
      <Button
        variant="secondary"
        onClick={() => setShowBestPractices(!showBestPractices)}
        className="w-full mt-2"
      >
        {showBestPractices
          ? "Hide Best Practices"
          : "Show Best Practices & Tutorial"}
      </Button>

      {showBestPractices && (
        <div className="space-y-4 mt-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-medium mb-2 flex items-center gap-2">
              <Sprout className="h-4 w-4" />
              Best Practices for {crop}
            </h4>
            <ul className="list-disc pl-5 space-y-1">
              {bestPractices.map((practice, index) => (
                <li key={index} className="text-sm text-muted-foreground">
                  {practice}
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium flex items-center gap-2">
              <FileInput className="h-4 w-4" />
              Planting Tutorial
            </h4>
            <div className="aspect-video w-full">
              <iframe
                className="w-full h-full rounded-lg"
                src={youtubeEmbedUrl}
                title={`${crop} Planting Tutorial`}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default CropBestPractices;
