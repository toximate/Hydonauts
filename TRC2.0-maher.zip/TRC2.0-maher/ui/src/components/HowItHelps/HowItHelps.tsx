import React from "react";
import Card from "./CardComp.jsx";
import Icon1 from "../../assets/icon/1.png";
import Icon2 from "../../assets/icon/2.png";
import Icon3 from "../../assets/icon/3.png";
import { motion } from "framer-motion";
import { SlideLeft, SlideRight } from "../../utility/animation";

const HowItHelps = () => {
  return (
    <section className="bg-gradient-to-b from-white to-[#F2F8F0] py-20">
      <div className="container py-10 my-10 px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-darkBlue mb-4">
            How It <span className="text-[#4CAF50]">Helps</span> People
          </h2>
          <div className="w-24 h-1 bg-[#4CAF50] mx-auto mt-4 mb-6 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="col-span-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              <motion.div
                variants={SlideRight(0.2)}
                whileInView={"animate"}
                initial="initial"
                className="transform hover:-translate-y-2 transition-all duration-300"
              >
                <Card
                  icon={Icon1}
                  heading="Symptoms"
                  text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Risussed volutpat non."
                />
              </motion.div>
              <motion.div
                variants={SlideRight(0.4)}
                whileInView={"animate"}
                initial="initial"
                className="transform hover:-translate-y-2 transition-all duration-300"
              >
                <Card
                  icon={Icon2}
                  heading="Recommendations"
                  text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Risussed volutpat non."
                />
              </motion.div>
              <motion.div
                variants={SlideRight(0.6)}
                whileInView={"animate"}
                initial="initial"
                className="transform hover:-translate-y-2 transition-all duration-300"
              >
                <Card
                  icon={Icon3}
                  heading="Local information"
                  text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Risussed volutpat non."
                />
              </motion.div>
            </div>
          </div>
          <motion.div
            variants={SlideLeft(0.8)}
            whileInView={"animate"}
            initial="initial"
            className="flex flex-col justify-center bg-white rounded-2xl shadow-lg p-8 border-l-4 border-[#4CAF50]"
          >
            <h1 className="text-3xl font-bold text-darkBlue">
              How it Helps people
            </h1>
            <div className="w-16 h-1 bg-[#4CAF50] my-4 rounded-full"></div>
            <p className="text-gray-600 mb-6">
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Odit
              esse ab natus.
            </p>
            <p className="text-sm text-gray-500 mb-6">
              Lorem ipsum dolor sit amet consectetur adipisicing elit.{" "}
              <a
                href="#"
                className="text-[#4CAF50] font-medium hover:underline"
              >
                Learn More
              </a>
            </p>
            <button className="w-fit mt-2 bg-white border-2 border-[#4CAF50] text-[#4CAF50] font-medium px-6 py-3 rounded-full hover:bg-[#4CAF50] hover:text-white transform transition-all duration-300">
              Get in Touch
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HowItHelps;
