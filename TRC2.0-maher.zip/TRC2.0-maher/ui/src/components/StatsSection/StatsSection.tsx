import React from "react";
import { motion } from "framer-motion";

const statsData = [
  {
    id: 1,
    title: "Irrigation Efficiency",
    value: "95%",
    description: "Percentage of water efficiently used in irrigation systems.",
  },
  {
    id: 2,
    title: "Crop Yield Improvement",
    value: "20%",
    description:
      "Average increase in crop yield through smart farming techniques.",
  },
  {
    id: 3,
    title: "Water Conservation",
    value: "30%",
    description: "Reduction in water usage through automated irrigation.",
  },
  {
    id: 4,
    title: "Sensor Accuracy",
    value: "98%",
    description:
      "Accuracy of environmental sensors used for monitoring crops and soil.",
  },
];

const StatsSection = () => {
  return (
    <div className="bg-[#F2F8F0] py-20">
      <div className="container px-4">
        <div className="space-y-4 text-center max-w-2xl mx-auto mb-12">
          <h3 className="uppercase font-semibold text-[#4CAF50] tracking-wider text-sm">
            Agriculture Efficiency Statistics
          </h3>
          <h2 className="font-bold text-3xl md:text-4xl text-darkBlue">
            How Smart Agriculture Optimizes Farming
          </h2>
          <div className="w-24 h-1 bg-[#4CAF50] mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 px-4">
          {statsData.map((stat) => (
            <motion.div
              key={stat.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{
                type: "spring",
                stiffness: 100,
                delay: stat.id * 0.1,
              }}
              whileHover={{
                scale: 1.05,
                boxShadow:
                  "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
              }}
              className="rounded-2xl p-8 flex flex-col items-center text-center bg-white border border-[#4CAF50]/20 shadow-lg hover:border-[#4CAF50] transition-all duration-300"
            >
              <div className="w-16 h-16 rounded-full bg-[#4CAF50]/10 flex items-center justify-center mb-4">
                <span className="text-4xl font-bold text-[#4CAF50]">
                  {stat.value.charAt(0)}
                </span>
              </div>
              <h2 className="text-4xl font-bold bg-gradient-to-r from-[#4CAF50] to-[#8BC34A] bg-clip-text text-transparent">
                {stat.value}
              </h2>
              <h3 className="font-semibold text-lg text-darkBlue mt-2 mb-1">
                {stat.title}
              </h3>
              <div className="w-12 h-1 bg-[#4CAF50]/40 rounded-full my-3"></div>
              <p className="text-gray-600">{stat.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StatsSection;
