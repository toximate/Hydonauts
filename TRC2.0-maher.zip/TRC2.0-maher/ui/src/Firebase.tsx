import { initializeApp } from "firebase/app";
import { getDatabase, ref, onValue } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyDUHzDnpvHJEpmnUyMmfLX2Mlc92JMXeQs",
  authDomain: "jardin-intelligente.firebaseapp.com",
  databaseURL: "https://jardin-intelligente-default-rtdb.firebaseio.com/",
  projectId: "jardin-intelligente",
  storageBucket: "jardin-intelligente.appspot.com",
  messagingSenderId: "974679659600",
  appId: "1:974679659600:web:d8a7ff1b6446763b216d55",
  measurementId: "G-4Q8WF8VYSP",
};
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

export { database, ref, onValue };
