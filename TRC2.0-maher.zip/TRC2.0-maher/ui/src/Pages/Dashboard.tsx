import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../components/ui/Cards";
import { Thermometer, Gauge, Wind, Cloud } from "lucide-react";

const API_KEY = "74b9b52faf141fabd4a1386b0eda2d30";
const CITY = "Tunis";
const API_URL = `https://api.openweathermap.org/data/2.5/weather?q=${CITY}&appid=${API_KEY}&units=metric&lang=en`;

const Dashboard = () => {
  const [weatherData, setWeatherData] = useState({
    temperature: [],
    pressure: [],
    windSpeed: [],
    cloudiness: [],
  });

  useEffect(() => {
    const fetchWeatherData = async () => {
      try {
        const response = await axios.get(API_URL);
        const data = response.data;

        setWeatherData((prev) => ({
          ...prev,
          temperature: [...prev.temperature, data.main.temp],
          pressure: [...prev.pressure, data.main.pressure],
          windSpeed: [...prev.windSpeed, data.wind.speed],
          cloudiness: [...prev.cloudiness, data.clouds.all],
        }));
      } catch (error) {
        console.error("Error fetching weather data", error);
      }
    };
    fetchWeatherData();
  }, []);

  const sensorConfigs = {
    temperature: {
      label: "Temperature",
      unit: "°C",
      color: "#F4A900",
      icon: <Thermometer className="h-5 w-5" />,
    },
    pressure: {
      label: "Pressure",
      unit: "hPa",
      color: "#8B5E3B",
      icon: <Gauge className="h-5 w-5" />,
    },
    windSpeed: {
      label: "Wind Speed",
      unit: "m/s",
      color: "#5DADE2",
      icon: <Wind className="h-5 w-5" />,
    },
    cloudiness: {
      label: "Cloudiness",
      unit: "%",
      color: "#607D8B",
      icon: <Cloud className="h-5 w-5" />,
    },
  };

  const renderSensorCard = (sensorKey) => {
    const config = sensorConfigs[sensorKey];
    const data = weatherData[sensorKey];
    const currentValue = data.length > 0 ? data[data.length - 1] : null;
    const previousValue = data.length > 1 ? data[data.length - 2] : null;
    const percentageChange =
      previousValue && currentValue
        ? ((currentValue - previousValue) / previousValue) * 100
        : 0;

    return (
      <Card className="bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg hover:shadow-xl transition-shadow duration-200">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div className="flex items-center space-x-3">
            <div
              className="p-2.5 rounded-xl"
              style={{ backgroundColor: `${config.color}15` }}
            >
              {React.cloneElement(config.icon, {
                className: "h-6 w-6",
                style: { color: config.color },
              })}
            </div>
            <div>
              <CardTitle className="text-xl font-bold font-poppins">
                {config.label}
              </CardTitle>
              <CardDescription className="text-sm text-darkBlue/70">
                Last updated: {new Date().toLocaleTimeString()}
              </CardDescription>
            </div>
          </div>
          <div className="flex flex-col items-end">
            <div
              className="text-3xl font-bold font-poppins"
              style={{ color: config.color }}
            >
              {currentValue !== null
                ? `${currentValue.toFixed(1)}${config.unit}`
                : "N/A"}
            </div>
            {percentageChange !== 0 && data.length > 1 && (
              <div
                className={`text-sm ${
                  percentageChange > 0 ? "text-green-500" : "text-red-500"
                }`}
              >
                {percentageChange > 0 ? "↑" : "↓"}{" "}
                {Math.abs(percentageChange).toFixed(1)}%
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[50px] flex items-center justify-center">
            {!currentValue && (
              <p className="text-darkBlue/70">No data available</p>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brandWhite/50 to-brandWhite/30 p-6 space-y-8">
      <div className="max-w-[1800px] mx-auto space-y-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/50 backdrop-blur-sm p-6 rounded-xl border border-brandWhite/50 shadow-md">
          <div>
            <h1 className="text-3xl font-bold font-poppins bg-clip-text text-transparent bg-gradient-to-r from-darkBlue to-blue-600">
              🌍 Weather Dashboard
            </h1>
            <p className="text-darkBlue/70 mt-1">
              Real-time weather monitoring for {CITY}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Object.keys(sensorConfigs).map((key) => renderSensorCard(key))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          <Card className="bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-bold font-poppins">
                Temperature Trend
              </CardTitle>
              <CardDescription className="text-darkBlue/70">
                Recent temperature measurements
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                {weatherData.temperature.length > 0 ? (
                  <ResponsiveContainer>
                    <LineChart
                      data={weatherData.temperature.map((value, index) => ({
                        value,
                        index,
                      }))}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="rgba(139,94,59,0.1)"
                      />
                      <XAxis
                        dataKey="index"
                        tickFormatter={(index) => (index + 1).toString()}
                        stroke="rgba(139,94,59,0.5)"
                        fontSize={12}
                      />
                      <YAxis stroke="rgba(139,94,59,0.5)" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "rgba(228,205,167,0.95)",
                          border: "1px solid rgba(139,94,59,0.1)",
                          borderRadius: "8px",
                        }}
                        formatter={(value) => [`${value}°C`, "Temperature"]}
                      />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke={sensorConfigs.temperature.color}
                        strokeWidth={2.5}
                        dot={true}
                        activeDot={{ r: 6, strokeWidth: 0 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full w-full flex items-center justify-center">
                    <p className="text-darkBlue/70">No data available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-bold font-poppins">
                Wind Speed Trend
              </CardTitle>
              <CardDescription className="text-darkBlue/70">
                Recent wind speed measurements
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                {weatherData.windSpeed.length > 0 ? (
                  <ResponsiveContainer>
                    <LineChart
                      data={weatherData.windSpeed.map((value, index) => ({
                        value,
                        index,
                      }))}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="rgba(139,94,59,0.1)"
                      />
                      <XAxis
                        dataKey="index"
                        tickFormatter={(index) => (index + 1).toString()}
                        stroke="rgba(139,94,59,0.5)"
                        fontSize={12}
                      />
                      <YAxis stroke="rgba(139,94,59,0.5)" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "rgba(228,205,167,0.95)",
                          border: "1px solid rgba(139,94,59,0.1)",
                          borderRadius: "8px",
                        }}
                        formatter={(value) => [`${value} m/s`, "Wind Speed"]}
                      />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke={sensorConfigs.windSpeed.color}
                        strokeWidth={2.5}
                        dot={true}
                        activeDot={{ r: 6, strokeWidth: 0 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full w-full flex items-center justify-center">
                    <p className="text-darkBlue/70">No data available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
