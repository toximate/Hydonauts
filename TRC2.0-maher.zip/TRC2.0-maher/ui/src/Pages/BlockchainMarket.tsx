import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  FaWater, 
  FaVoteYea, 
  FaCoins, 
  FaHandshake, 
  FaChartLine, 
  FaUsers,
  FaLeaf,
  FaShieldAlt,
  FaExchangeAlt
} from "react-icons/fa";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/Cards";
import { Button } from "../components/ui/Button";

interface WaterContract {
  id: number;
  seller: string;
  amount: number; // in liters
  price: number; // in tokens per liter
  quality: "Premium" | "Standard" | "Basic";
  location: string;
  availableUntil: string;
  verified: boolean;
}

interface DAOProposal {
  id: number;
  title: string;
  description: string;
  proposer: string;
  votes: {
    yes: number;
    no: number;
  };
  deadline: string;
  status: "Active" | "Passed" | "Rejected" | "Pending";
  type: "Infrastructure" | "Policy" | "Budget" | "Emergency";
}

const BlockchainMarket: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"marketplace" | "dao" | "governance">("marketplace");
  const [userTokens, setUserTokens] = useState(1250);
  const [userReputation, setUserReputation] = useState(85);

  // Mock data for water contracts
  const [waterContracts] = useState<WaterContract[]>([
    {
      id: 1,
      seller: "Green Valley Farm",
      amount: 5000,
      price: 0.02,
      quality: "Premium",
      location: "North Valley",
      availableUntil: "2025-06-20",
      verified: true
    },
    {
      id: 2,
      seller: "Sustainable Acres",
      amount: 3000,
      price: 0.015,
      quality: "Standard",
      location: "East Ridge",
      availableUntil: "2025-06-18",
      verified: true
    },
    {
      id: 3,
      seller: "EcoFarm Collective",
      amount: 8000,
      price: 0.025,
      quality: "Premium",
      location: "South Plains",
      availableUntil: "2025-06-25",
      verified: false
    }
  ]);

  // Mock data for DAO proposals
  const [daoProposals] = useState<DAOProposal[]>([
    {
      id: 1,
      title: "Install Smart Water Sensors in Region A",
      description: "Proposal to install 50 IoT water quality sensors across Region A to improve monitoring and data collection.",
      proposer: "TechFarm Solutions",
      votes: { yes: 245, no: 67 },
      deadline: "2025-06-20",
      status: "Active",
      type: "Infrastructure"
    },
    {
      id: 2,
      title: "Establish Water Conservation Incentive Program",
      description: "Create a token-based reward system for farmers who demonstrate water conservation practices.",
      proposer: "Water Conservation Alliance",
      votes: { yes: 189, no: 23 },
      deadline: "2025-06-22",
      status: "Active",
      type: "Policy"
    },
    {
      id: 3,
      title: "Emergency Water Relief Fund",
      description: "Allocate 100,000 tokens for emergency water assistance during drought conditions.",
      proposer: "Community Relief Committee",
      votes: { yes: 456, no: 12 },
      deadline: "2025-06-16",
      status: "Passed",
      type: "Emergency"
    }
  ]);

  const getQualityColor = (quality: string) => {
    switch (quality) {
      case "Premium": return "text-green-600 bg-green-100";
      case "Standard": return "text-blue-600 bg-blue-100";
      case "Basic": return "text-gray-600 bg-gray-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active": return "text-blue-600 bg-blue-100";
      case "Passed": return "text-green-600 bg-green-100";
      case "Rejected": return "text-red-600 bg-red-100";
      case "Pending": return "text-yellow-600 bg-yellow-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const MarketplaceTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Your Tokens</p>
                <p className="text-2xl font-bold text-blue-600">{userTokens.toLocaleString()}</p>
              </div>
              <FaCoins className="text-3xl text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Reputation Score</p>
                <p className="text-2xl font-bold text-green-600">{userReputation}/100</p>
              </div>
              <FaShieldAlt className="text-3xl text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Contracts</p>
                <p className="text-2xl font-bold text-purple-600">7</p>
              </div>
              <FaHandshake className="text-3xl text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-4 flex items-center">
          <FaWater className="mr-2 text-blue-500" />
          Available Water Contracts
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {waterContracts.map((contract) => (
            <Card key={contract.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{contract.seller}</span>
                  {contract.verified && <FaShieldAlt className="text-green-500" />}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Amount:</span>
                    <span className="font-semibold">{contract.amount.toLocaleString()}L</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Price:</span>
                    <span className="font-semibold">{contract.price} tokens/L</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Quality:</span>
                    <span className={`px-2 py-1 rounded text-xs ${getQualityColor(contract.quality)}`}>
                      {contract.quality}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Location:</span>
                    <span className="font-semibold">{contract.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Available until:</span>
                    <span className="font-semibold">{contract.availableUntil}</span>
                  </div>
                  <Button className="w-full mt-4">
                    Purchase Contract
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const DAOTab = () => (
    <div className="space-y-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-4 flex items-center">
          <FaVoteYea className="mr-2 text-indigo-500" />
          Community Governance Proposals
        </h2>
        <p className="text-gray-600 mb-6">
          Participate in decentralized decision-making for water management infrastructure and policies.
        </p>
        
        <div className="space-y-6">
          {daoProposals.map((proposal) => (
            <Card key={proposal.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{proposal.title}</span>
                  <span className={`px-3 py-1 rounded text-sm ${getStatusColor(proposal.status)}`}>
                    {proposal.status}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-gray-700">{proposal.description}</p>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-gray-600">Proposer:</span>
                      <p className="font-semibold">{proposal.proposer}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Type:</span>
                      <p className="font-semibold">{proposal.type}</p>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-600">Voting Results:</span>
                      <span className="text-sm text-gray-500">Deadline: {proposal.deadline}</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-green-600">Yes: {proposal.votes.yes}</span>
                        <span className="text-red-600">No: {proposal.votes.no}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full"
                          style={{ 
                            width: `${(proposal.votes.yes / (proposal.votes.yes + proposal.votes.no)) * 100}%` 
                          }}
                        ></div>
                      </div>
                    </div>
                  </div>
                  
                  {proposal.status === "Active" && (
                    <div className="flex gap-3">
                      <Button className="flex-1">
                        Vote Yes
                      </Button>
                      <Button className="flex-1">
                        Vote No
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const GovernanceTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FaUsers className="mr-2 text-blue-500" />
              Community Stats
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span>Total Members:</span>
                <span className="font-bold">1,247</span>
              </div>
              <div className="flex justify-between">
                <span>Active Voters:</span>
                <span className="font-bold">892</span>
              </div>
              <div className="flex justify-between">
                <span>Total Proposals:</span>
                <span className="font-bold">156</span>
              </div>
              <div className="flex justify-between">
                <span>Passed Proposals:</span>
                <span className="font-bold text-green-600">124</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FaChartLine className="mr-2 text-green-500" />
              Treasury & Resources
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span>Treasury Balance:</span>
                <span className="font-bold">2.5M Tokens</span>
              </div>
              <div className="flex justify-between">
                <span>Water Reserves:</span>
                <span className="font-bold">450K Liters</span>
              </div>
              <div className="flex justify-between">
                <span>Infrastructure Assets:</span>
                <span className="font-bold">$1.2M</span>
              </div>
              <div className="flex justify-between">
                <span>Monthly Revenue:</span>
                <span className="font-bold text-green-600">+15.3%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Create New Proposal</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Proposal Title</label>
              <input 
                type="text" 
                className="w-full p-3 border rounded-lg"
                placeholder="Enter proposal title..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Proposal Type</label>
              <select className="w-full p-3 border rounded-lg">
                <option>Infrastructure</option>
                <option>Policy</option>
                <option>Budget</option>
                <option>Emergency</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Description</label>
              <textarea 
                className="w-full p-3 border rounded-lg h-32"
                placeholder="Describe your proposal in detail..."
              ></textarea>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Voting Duration (days)</label>
                <input 
                  type="number" 
                  className="w-full p-3 border rounded-lg"
                  placeholder="7"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Required Stake (tokens)</label>
                <input 
                  type="number" 
                  className="w-full p-3 border rounded-lg"
                  placeholder="100"
                />
              </div>
            </div>
            <Button className="w-full">
              Submit Proposal
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-800 mb-4 flex items-center justify-center">
              <FaLeaf className="mr-3 text-green-500" />
              Blockchain Water Market & DAO
            </h1>
            <p className="text-xl text-gray-600">
              Community-driven water management through blockchain technology and decentralized governance
            </p>
          </div>

          {/* Tab Navigation */}
          <div className="flex flex-wrap justify-center mb-8">
            <div className="bg-white rounded-lg p-1 shadow-md">
              <button
                onClick={() => setActiveTab("marketplace")}
                className={`px-6 py-3 rounded-lg transition-all ${
                  activeTab === "marketplace"
                    ? "bg-blue-500 text-white shadow-md"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                <FaExchangeAlt className="inline mr-2" />
                Water Marketplace
              </button>
              <button
                onClick={() => setActiveTab("dao")}
                className={`px-6 py-3 rounded-lg transition-all ${
                  activeTab === "dao"
                    ? "bg-blue-500 text-white shadow-md"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                <FaVoteYea className="inline mr-2" />
                DAO Proposals
              </button>
              <button
                onClick={() => setActiveTab("governance")}
                className={`px-6 py-3 rounded-lg transition-all ${
                  activeTab === "governance"
                    ? "bg-blue-500 text-white shadow-md"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                <FaUsers className="inline mr-2" />
                Governance
              </button>
            </div>
          </div>

          {/* Tab Content */}
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === "marketplace" && <MarketplaceTab />}
            {activeTab === "dao" && <DAOTab />}
            {activeTab === "governance" && <GovernanceTab />}
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default BlockchainMarket;
