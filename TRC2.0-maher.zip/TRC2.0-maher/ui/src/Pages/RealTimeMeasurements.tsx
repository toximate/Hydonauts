import React from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/Cards";
import {
  Activity,
  Droplets,
  Leaf,
  Thermometer,
  TrendingUp,
} from "lucide-react";
import { cn } from "../utility/cn";

type RealTimeData = {
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  temperature: number;
  humidity: number;
  pH_Value: number;
  rainfall: number;
  timestamp: string;
};

type MeasurementCardProps = {
  title: string;
  value: number;
  unit: string;
  icon: React.ReactNode;
  color: string;
  trend?: number;
  previousValue?: number;
};

const MeasurementCard: React.FC<MeasurementCardProps> = ({
  title,
  value,
  unit,
  icon,
  color,
  trend,
  previousValue,
}) => {
  const trendPercentage = trend
    ? ((value - (previousValue || 0)) / (previousValue || 1)) * 100
    : 0;

  return (
    <Card className="relative overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center space-x-2">
          <div
            className="p-2 rounded-lg"
            style={{ backgroundColor: `${color}15` }}
          >
            {React.cloneElement(icon as React.ReactElement, {
              className: "h-5 w-5",
              style: { color },
            })}
          </div>
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col">
          <div className="text-2xl font-bold" style={{ color }}>
            {value.toFixed(2)}
            <span className="text-sm ml-1">{unit}</span>
          </div>
          {trend !== undefined && Math.abs(trendPercentage) >= 0.1 && (
            <div
              className={cn(
                "flex items-center text-xs mt-1",
                trendPercentage > 0
                  ? "text-green-500"
                  : trendPercentage < 0
                  ? "text-red-500"
                  : "text-gray-500"
              )}
            >
              <TrendingUp
                className={cn(
                  "h-3 w-3 mr-1",
                  trendPercentage > 0 ? "rotate-0" : "rotate-180"
                )}
              />
              {Math.abs(trendPercentage).toFixed(1)}% from previous
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

interface RealTimeMeasurementsProps {
  data: RealTimeData;
  previousData?: RealTimeData;
}

const RealTimeMeasurements: React.FC<RealTimeMeasurementsProps> = ({
  data,
  previousData,
}) => {
  const measurements = [
    {
      title: "Temperature",
      value: data.temperature,
      previousValue: previousData?.temperature,
      unit: "°C",
      icon: <Thermometer />,
      color: "#ef4444",
    },
    {
      title: "Humidity",
      value: data.humidity,
      previousValue: previousData?.humidity,
      unit: "%",
      icon: <Droplets />,
      color: "#06b6d4",
    },
    {
      title: "pH Value",
      value: data.pH_Value,
      previousValue: previousData?.pH_Value,
      unit: "pH",
      icon: <Activity />,
      color: "#a855f7",
    },
    {
      title: "Nitrogen",
      value: data.nitrogen,
      previousValue: previousData?.nitrogen,
      unit: "%",
      icon: <Leaf />,
      color: "#22c55e",
    },
    {
      title: "Phosphorus",
      value: data.phosphorus,
      previousValue: previousData?.phosphorus,
      unit: "%",
      icon: <Leaf />,
      color: "#3b82f6",
    },
    {
      title: "Potassium",
      value: data.potassium,
      previousValue: previousData?.potassium,
      unit: "%",
      icon: <Leaf />,
      color: "#eab308",
    },
    {
      title: "Rainfall",
      value: data.rainfall,
      previousValue: previousData?.rainfall,
      unit: "mm",
      icon: <Droplets />,
      color: "#0ea5e9",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {measurements.map((measurement) => (
          <MeasurementCard
            key={measurement.title}
            {...measurement}
            trend={
              measurement.previousValue
                ? measurement.value - measurement.previousValue
                : undefined
            }
          />
        ))}
      </div>
      <div className="text-sm text-muted-foreground text-right">
        Last updated: {new Date(data.timestamp).toLocaleString()}
      </div>
    </div>
  );
};

export default RealTimeMeasurements;
