import React from "react";
import MarkdownRenderer from "../components/ui/MarkdownRenderer";

const MyPage: React.FC = () => {
  const markdownContent = `## Agricultural Data Analysis Report

**1. Insightful Analysis:**

*   **Mann-Kendall Trend Test (2.3, p-value: 0.04):**
    *   **Insight:** Indicates a statistically significant (p < 0.05) increasing trend in the analyzed data series (e.g., crop yield, soil organic matter, rainfall).
    *   **Reasoning:** A positive Mann-Kendall statistic (2.3) suggests an upward trend. The p-value below 0.05 confirms that this trend is unlikely to be due to random chance.   
    *   **Implication:** If the analyzed series is crop yield, it indicates a positive performance trend. If it's soil erosion, it's an alarming trend demanding intervention.     
*   **Lag-1 Autocorrelation (0.65):**
    *   **Insight:**  Strong positive autocorrelation in the data series. Current values are significantly influenced by the previous period's values.
    *   **Reasoning:** A value close to 1 indicates high persistence. This suggests that a good or bad year is likely to be followed by a similar one, impacting forecasting and risk management.
    *   **Implication:**  If the analyzed series is rainfall, a wet year is more likely to be followed by another wet year. This has implications for irrigation planning and flood control. This also suggests the need for time series modelling in any analysis.
*   **Cross-Correlation (Rainfall vs. Humidity: Lag 2, Correlation 0.78):**
    *   **Insight:**  Strong positive correlation between rainfall and humidity, with humidity lagging rainfall by two time periods (e.g., days or weeks).
    *   **Reasoning:** High correlation (0.78) suggests a strong relationship. The Lag 2 implies that the effect of rainfall on humidity is not immediate, likely due to factors like soil moisture evaporation and plant transpiration.
    *   **Implication:**  This is useful for predicting future humidity levels based on past rainfall patterns. This knowledge can be used for disease prediction (fungal diseases thrive in humid conditions) and irrigation scheduling.
*   **Nutrient Balance Ratio (N:P:K: 1:0.5:0.8):**
    *   **Insight:**  The nutrient balance is skewed towards higher nitrogen (N) relative to phosphorus (P) and potassium (K).
    *   **Reasoning:** Ideal N:P:K ratios vary by crop type, but generally, this indicates a potential deficiency in phosphorus and potassium. Many crops benefit from an N:P:K ratio closer to 1:1:1 or slightly higher P and K during certain growth stages.
    *   **Implication:** This could lead to reduced crop yields, weakened plant structures, and increased susceptibility to diseases due to nutrient imbalances.  Excess nitrogen can also contribute to environmental pollution (nitrate leaching).
*   **Growing Degree Days (GDD: 1200):**
    *   **Insight:** The accumulated GDD value provides information about the heat accumulation during the growing season.
    *   **Reasoning:** GDD is a measure of heat accumulation required for crop development.  1200 GDD provides information on the total heat units available for crops in the area.
    *   **Implication:**  This value should be compared to the GDD requirements of specific crops to determine if the climate is suitable for their growth and development. If 1200 GDD is below the requirements, crops might not reach maturity. If it exceeds the requirements, faster crop development, decreased yield and water stress might occur.

**2. Actionable Recommendations:**

*   **Address the Mann-Kendall Trend:**
    *   **If positive trend indicates desired outcome (e.g., increasing yield):** Analyze the drivers behind the improvement. Document best practices and promote their adoption to sustain the positive trend.
    *   **If positive trend indicates undesired outcome (e.g., increasing erosion):** Implement soil conservation practices such as cover cropping, contour plowing, and no-till farming to mitigate erosion. Monitor the trend closely and adjust practices as needed.

*   **Mitigate Autocorrelation Impacts:**
    *   **Recommendation:** Develop proactive risk management strategies that consider the persistence of climatic events.
    *   **Evidence:** The high lag-1 autocorrelation requires farmers to be aware of multi-year weather patterns and their impact on crop production.
    *   **Action:** Promote crop diversification to reduce vulnerability to specific weather events that tend to persist. Implement water harvesting strategies to buffer against drought during dry spells.

*   **Utilize Rainfall-Humidity Relationship:**
    *   **Recommendation:** Use rainfall data to predict future humidity levels and implement timely disease management strategies.
    *   **Evidence:** The high cross-correlation between rainfall and humidity provides an opportunity for proactive disease management.
    *   **Action:** Develop predictive models based on the rainfall-humidity relationship to forecast disease outbreaks and implement preventative measures such as fungicide applications only when needed to reduce chemical use.

*   **Optimize Nutrient Management:**
    *   **Recommendation:** Conduct soil testing to determine actual nutrient deficiencies and adjust fertilizer applications accordingly.
    *   **Evidence:** The imbalanced N:P:K ratio suggests potential deficiencies in phosphorus and potassium.
    *   **Action:** Implement precision agriculture techniques such as variable-rate fertilization to apply nutrients according to crop needs and soil conditions. Use organic amendments such as compost and manure to improve soil fertility and reduce reliance on synthetic fertilizers.

*   **Assess Crop Suitability based on GDD:**
    *   **Recommendation:** Match crop selection to the available GDD to optimize yield and minimize risk.
    *   **Evidence:** The GDD value provides a critical indication of the region's suitability for different crops.
    *   **Action:** Choose crop varieties that are well-suited to the local GDD range. Implement climate-smart agriculture practices such as adjusting planting dates to maximize GDD utilization and minimize the impact of extreme weather events. Also, monitor heat units accumulation and make adjustments to irrigation or crop management activities, if necessary.

By implementing these recommendations, agricultural practices can become more sustainable, productive, and resilient to environmental challenges. Continuous monitoring and adaptive management are crucial for achieving long-term success.`;

  return (
    <div>
      <MarkdownRenderer
        content={markdownContent}
        className="p-4 bg-white shadow-md rounded-lg"
      />
    </div>
  );
};

export default MyPage;
