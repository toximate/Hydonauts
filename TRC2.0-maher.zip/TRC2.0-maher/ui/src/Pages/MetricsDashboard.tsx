import React, { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../components/ui/Cards";
import { TrendingUp, Repeat, BarChart, PieChart, Clock } from "lucide-react";
import SoilInsightCard, { SensorData } from "../components/SoilInsightCard";
import CropRecommendation from "../components/CropRecommendation";

// Simulated data for demonstration
// In a real app, this would come from your actual dataset
const mockMetricsData = {
  mannKendallTest: [
    { feature: "Temperature", tauValue: 0.3, pValue: 0.02 },
    { feature: "Rainfall", tauValue: -0.1, pValue: 0.45 },
  ],
  autocorrelation: [
    { feature: "Humidity", value: 0.65 },
    { feature: "pH Value", value: 0.4 },
  ],
  crossCorrelation: [
    { features: "Rainfall vs Humidity", lag: 2, correlation: 0.78 },
  ],
  nutrientBalanceRatio: {
    nitrogen: 4,
    phosphorus: 1,
    potassium: 2,
    interpretation: "Slight nitrogen excess",
  },
  growingDegreeDays: {
    total: 1200,
    baseTemperature: 10,
    cropThreshold: 1500,
    interpretation: "Moderate heat accumulation",
  },
};

const MetricsDashboard: React.FC = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>("all");
  const [showInsights, setShowInsights] = useState(false);
  const [realTimeData, setRealTimeData] = useState<SensorData | null>(null);

  const timeframeOptions = [
    { value: "all", label: "All Data" },
    { value: "lastMonth", label: "Last Month" },
    { value: "lastQuarter", label: "Last Quarter" },
  ];

  // Simulate real-time data updates with gradual changes
  useEffect(() => {
    // Generate initial random data
    const initialData: SensorData = {
      timestamp: new Date().toISOString(),
      nitrogen: 40 + Math.random() * 20, // 40-60 range
      phosphorus: 20 + Math.random() * 10, // 20-30 range
      potassium: 50 + Math.random() * 20, // 50-70 range
      temperature: 22 + Math.random() * 5, // 22-27 range
      humidity: 50 + Math.random() * 20, // 50-70 range
      pH_Value: 6 + Math.random() * 2, // 6-8 range
      rainfall: 20 + Math.random() * 10, // 20-30 range
    };

    setRealTimeData(initialData);

    // Function to generate small random changes
    const generateSmallChange = (current: number, max: number) => {
      const maxChange = max * 0.02; // Maximum 2% change
      const change = (Math.random() - 0.5) * maxChange;
      return Math.max(0, Math.min(max, current + change));
    };

    const interval = setInterval(() => {
      if (realTimeData) {
        setRealTimeData((prev) => {
          if (!prev) return null;
          return {
            timestamp: new Date().toISOString(),
            nitrogen: generateSmallChange(prev.nitrogen, 100),
            phosphorus: generateSmallChange(prev.phosphorus, 50),
            potassium: generateSmallChange(prev.potassium, 100),
            temperature: generateSmallChange(prev.temperature, 35),
            humidity: generateSmallChange(prev.humidity, 100),
            pH_Value: generateSmallChange(prev.pH_Value, 14),
            rainfall: generateSmallChange(prev.rainfall, 50),
          };
        });
      }
    }, 10000); // Update every 10 seconds

    return () => clearInterval(interval);
  }, []);

  const renderMetricCard = (
    title: string,
    description: string,
    icon: React.ReactNode,
    content: React.ReactNode
  ) => (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-lg bg-primary/10">{icon}</div>
          <div>
            <CardTitle className="text-xl">{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>{content}</CardContent>
    </Card>
  );

  const renderMannKendallTest = () => {
    return (
      <div className="space-y-2">
        {mockMetricsData.mannKendallTest.map((test, index) => (
          <div key={index} className="flex justify-between items-center">
            <span>{test.feature}</span>
            <div className="flex space-x-2">
              <span
                className={`px-2 py-1 rounded text-xs ${
                  test.pValue <= 0.05
                    ? "bg-green-100 text-green-800"
                    : "bg-gray-100 text-gray-800"
                }`}
              >
                p-value: {test.pValue.toFixed(3)}
              </span>
              <span
                className={`px-2 py-1 rounded text-xs ${
                  test.tauValue > 0
                    ? "bg-blue-100 text-blue-800"
                    : "bg-red-100 text-red-800"
                }`}
              >
                Trend: {test.tauValue > 0 ? "Increasing" : "Decreasing"}
              </span>
            </div>
          </div>
        ))}
        <p className="text-sm text-muted-foreground mt-2">
          Significant trend detected where p-value ≤ 0.05
        </p>
      </div>
    );
  };

  const renderAutocorrelation = () => {
    return (
      <div className="space-y-2">
        {mockMetricsData.autocorrelation.map((metric, index) => (
          <div key={index} className="flex justify-between items-center">
            <span>{metric.feature}</span>
            <span
              className={`px-2 py-1 rounded text-xs ${
                metric.value > 0.5
                  ? "bg-green-100 text-green-800"
                  : "bg-gray-100 text-gray-800"
              }`}
            >
              Autocorrelation: {metric.value.toFixed(2)}
            </span>
          </div>
        ))}
        <p className="text-sm text-muted-foreground mt-2">
          Values near 1 indicate high temporal persistence
        </p>
      </div>
    );
  };

  const renderCrossCorrelation = () => {
    const cc = mockMetricsData.crossCorrelation[0];
    return (
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span>{cc.features}</span>
          <div className="flex space-x-2">
            <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
              Lag: {cc.lag}
            </span>
            <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
              Correlation: {cc.correlation.toFixed(2)}
            </span>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          Indicates lagged relationship between variables
        </p>
      </div>
    );
  };

  const renderNutrientBalanceRatio = () => {
    const nbr = mockMetricsData.nutrientBalanceRatio;
    return (
      <div className="space-y-2">
        <div className="flex justify-between">
          <span>N:P:K Ratio</span>
          <span className="font-bold">{`${nbr.nitrogen}:${nbr.phosphorus}:${nbr.potassium}`}</span>
        </div>
        <div className="flex justify-between items-center">
          <span>Interpretation</span>
          <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">
            {nbr.interpretation}
          </span>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          Balanced nutrients are crucial for optimal crop growth
        </p>
      </div>
    );
  };

  const renderGrowingDegreeDays = () => {
    const gdd = mockMetricsData.growingDegreeDays;
    return (
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span>Total Growing Degree Days</span>
          <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
            {gdd.total}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span>Base Temperature</span>
          <span>{gdd.baseTemperature}°C</span>
        </div>
        <div className="flex justify-between items-center">
          <span>Crop Threshold</span>
          <span>{gdd.cropThreshold}</span>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          {gdd.interpretation}
        </p>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <CropRecommendation currentData={realTimeData} />
      </div>
    </div>
  );
};

export default MetricsDashboard;
