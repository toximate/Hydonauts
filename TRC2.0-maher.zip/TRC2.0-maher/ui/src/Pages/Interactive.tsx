import React, { useState } from "react";
import ConstructionFarm from "../components/Interactive_monitoring/ConstructionFarm";
import PlacementWaterDrops from "../components/Interactive_monitoring/PlacementWaterDrops.tsx";
import Visualisation from "../components/Interactive_monitoring/Visualisation";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../components/ui/Cards";

const Interactive_monitoring = () => {
  const [grid, setGrid] = useState(
    Array.from({ length: 10 }, () => Array(10).fill(null))
  );
  const [message, setMessage] = useState("");
  const [activeTab, setActiveTab] = useState("construction");

  const resetGrid = () => {
    setGrid(Array.from({ length: 10 }, () => Array(10).fill(null)));
    setMessage("");
  };

  const saveGrid = () => {
    localStorage.setItem("savedGrid", JSON.stringify(grid));
    setMessage("Farm layout successfully saved!");
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "construction":
        return <ConstructionFarm grid={grid} setGrid={setGrid} />;
      case "placement":
        return <PlacementWaterDrops grid={grid} setGrid={setGrid} />;
      case "visualization":
        return <Visualisation grid={grid} />;
      default:
        return <ConstructionFarm grid={grid} setGrid={setGrid} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brandWhite/50 to-brandWhite/30 p-6 space-y-6">
      <div className="max-w-[1800px] mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/50 backdrop-blur-sm p-6 rounded-xl border border-brandWhite/50 shadow-md">
          <div>
            <h1 className="text-3xl font-bold font-poppins bg-clip-text text-transparent bg-gradient-to-r from-darkBlue to-blue-600">
              🌾 Interactive Farm Supervision
            </h1>
            <p className="text-darkBlue/70 mt-1">
              Design, monitor and optimize your farm layout
            </p>
          </div>
        </div>

        <div className="bg-white/50 backdrop-blur-sm border border-brandWhite/50 rounded-xl shadow-lg p-6">
          <div className="flex flex-wrap gap-3 mb-6">
            <button
              onClick={() => setActiveTab("construction")}
              className={`px-4 py-2 font-medium rounded-lg transition-all duration-200 flex items-center gap-2 ${
                activeTab === "construction"
                  ? "bg-darkBlue text-white shadow-md"
                  : "bg-white/70 hover:bg-white text-darkBlue/80 hover:shadow-sm"
              }`}
            >
              <span className="text-lg">🏡</span>
              Phase 1: Building the Farm
            </button>
            <button
              onClick={() => setActiveTab("placement")}
              className={`px-4 py-2 font-medium rounded-lg transition-all duration-200 flex items-center gap-2 ${
                activeTab === "placement"
                  ? "bg-darkBlue text-white shadow-md"
                  : "bg-white/70 hover:bg-white text-darkBlue/80 hover:shadow-sm"
              }`}
            >
              <span className="text-lg">💧</span>
              Phase 2: Placement of "EcoSyn MK-1"
            </button>
            <button
              onClick={() => setActiveTab("visualization")}
              className={`px-4 py-2 font-medium rounded-lg transition-all duration-200 flex items-center gap-2 ${
                activeTab === "visualization"
                  ? "bg-darkBlue text-white shadow-md"
                  : "bg-white/70 hover:bg-white text-darkBlue/80 hover:shadow-sm"
              }`}
            >
              <span className="text-lg">📊</span>
              Phase 3: Real-time visualization
            </button>
          </div>

          <Card className="bg-white/70 border border-brandWhite/50 shadow-md">
            <CardHeader>
              <CardTitle className="text-xl font-bold font-poppins">
                {activeTab === "construction" && "Farm Layout Designer"}
                {activeTab === "placement" && "Water Sensor Placement"}
                {activeTab === "visualization" && "Sensor Status Visualization"}
              </CardTitle>
              <CardDescription className="text-darkBlue/70">
                {activeTab === "construction" &&
                  "Design your farm by placing different elements"}
                {activeTab === "placement" &&
                  "Place EcoSyn MK-1 water sensors on your farm"}
                {activeTab === "visualization" &&
                  "Monitor water sensor status in real-time"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-6">{renderTabContent()}</div>

              <div className="flex flex-wrap gap-3 mt-6">
                <button
                  onClick={resetGrid}
                  className="px-4 py-2 bg-red-400 hover:bg-red-500 text-white font-medium rounded-lg transition-colors duration-200 shadow-sm hover:shadow-md"
                >
                  Reset Grid
                </button>
                <button
                  onClick={saveGrid}
                  className="px-4 py-2 bg-blue-400 hover:bg-blue-500 text-white font-medium rounded-lg transition-colors duration-200 shadow-sm hover:shadow-md"
                >
                  Save the grid
                </button>
              </div>

              {message && (
                <div className="mt-4 p-3 bg-green-100 text-green-700 rounded-lg border border-green-200">
                  {message}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Interactive_monitoring;
