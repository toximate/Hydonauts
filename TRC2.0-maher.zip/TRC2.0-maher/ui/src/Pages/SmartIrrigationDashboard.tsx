import React from "react";
import { useState, useEffect } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from "recharts";
import {
  Droplets,
  Thermometer,
  Waves,
  Calendar,
  Clock,
  AlertCircle,
  Check,
  X,
  ChevronRight,
  Settings,
  History,
  BarChart2,
  BarChart3,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../components/ui/Cards";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/Selects";
import { Link } from "react-router-dom";

export default function SmartIrrigationDashboard() {
  const [selectedSection, setSelectedSection] = useState("Section 1");
  const [soilHumidity, setSoilHumidity] = useState(39.9);
  const [soilMoisture, setSoilMoisture] = useState(0);
  const [temperature, setTemperature] = useState(20.2);
  const [moistureData, setMoistureData] = useState([]);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");
  const [isIrrigating, setIsIrrigating] = useState(false);
  const [selectedTimeRange, setSelectedTimeRange] = useState("2h");
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [statusMessage, setStatusMessage] = useState("System idle");

  const farmSections = [
    "Section 1",
    "Section 2",
    "Section 3",
    "Section 4",
    "North Field",
    "South Field",
    "East Field",
    "West Field",
  ];

  const timeRanges = [
    { label: "2h", value: "2h" },
    { label: "6h", value: "6h" },
    { label: "12h", value: "12h" },
    { label: "24h", value: "24h" },
  ];

  const irrigationHistory = [
    {
      section: "Section 1",
      date: "Apr 14, 2025",
      time: "08:30 AM",
      duration: "45 min",
    },
    {
      section: "East Field",
      date: "Apr 13, 2025",
      time: "07:15 PM",
      duration: "30 min",
    },
    {
      section: "North Field",
      date: "Apr 13, 2025",
      time: "10:00 AM",
      duration: "60 min",
    },
    {
      section: "Section 3",
      date: "Apr 12, 2025",
      time: "06:45 AM",
      duration: "40 min",
    },
  ];

  useEffect(() => {
    // Simulate fetching data for the selected section
    generateSectionData(selectedSection);

    // Update timestamp
    setLastUpdated(new Date());
  }, [selectedSection, selectedTimeRange]);

  const generateSectionData = (section) => {
    // This would be replaced with actual API calls in a real application
    // Generate random values for demo purposes that vary slightly by section
    const sectionIndex = farmSections.indexOf(section);
    const baseHumidity = 35 + sectionIndex * 2 + Math.random() * 10;
    const baseMoisture = sectionIndex * 5 + Math.random() * 10;
    const baseTemp = 18 + sectionIndex * 0.5 + Math.random() * 4;

    setSoilHumidity(parseFloat(baseHumidity.toFixed(1)));
    setSoilMoisture(parseFloat(baseMoisture.toFixed(1)));
    setTemperature(parseFloat(baseTemp.toFixed(1)));

    // Generate chart data based on selected time range
    const dataPoints =
      selectedTimeRange === "2h"
        ? 12
        : selectedTimeRange === "6h"
        ? 36
        : selectedTimeRange === "12h"
        ? 72
        : 144;

    const interval =
      selectedTimeRange === "2h"
        ? 10
        : selectedTimeRange === "6h"
        ? 10
        : selectedTimeRange === "12h"
        ? 10
        : 10;

    const data = [];
    for (let i = 0; i <= interval * dataPoints; i += interval) {
      const moistureValue =
        baseMoisture + Math.sin(i / 20) * 5 + (Math.random() * 2 - 1);
      const humidityValue =
        baseHumidity + Math.cos(i / 25) * 3 + (Math.random() * 2 - 1);
      const tempValue =
        baseTemp + Math.sin(i / 40) * 1.5 + (Math.random() * 1 - 0.5);

      data.push({
        time: `${i} min`,
        moisture: parseFloat(moistureValue.toFixed(1)),
        humidity: parseFloat(humidityValue.toFixed(1)),
        temperature: parseFloat(tempValue.toFixed(1)),
      });
    }
    setMoistureData(data);
  };

  const handleStartIrrigation = () => {
    setIsIrrigating(true);
    setStatusMessage(`Irrigating ${selectedSection}...`);
    showNotificationMessage(`Irrigation started for ${selectedSection}`);
  };

  const handleStopIrrigation = () => {
    setIsIrrigating(false);
    setStatusMessage("System idle");
    showNotificationMessage(`Irrigation stopped for ${selectedSection}`);
  };

  const showNotificationMessage = (message) => {
    setNotificationMessage(message);
    setShowNotification(true);
    setTimeout(() => {
      setShowNotification(false);
    }, 3000);
  };

  const getStatusColor = () => {
    if (isIrrigating) return "text-primary";
    if (soilMoisture < 20) return "text-accentYellow";
    if (soilMoisture < 30) return "text-accentYellow";
    return "text-darkBlue";
  };

  const getMoistureStatus = () => {
    if (soilMoisture < 20) return "Low";
    if (soilMoisture < 40) return "Medium";
    if (soilMoisture < 70) return "Good";
    return "Excellent";
  };

  const getMoistureStatusColor = () => {
    if (soilMoisture < 20) return "text-accentYellow";
    if (soilMoisture < 40) return "text-accentYellow";
    if (soilMoisture < 70) return "text-primary";
    return "text-darkBlue";
  };

  const refresh = () => {
    generateSectionData(selectedSection);
    setLastUpdated(new Date());
    showNotificationMessage("Data refreshed");
  };

  // Define sensor config styles consistent with SeasonalSensorDashboard
  const sensorConfigs = {
    humidity: {
      label: "Soil Humidity",
      unit: "%",
      color: "#5DADE2", // Blue color from SeasonalSensorDashboard
      icon: <Droplets className="h-5 w-5" />,
      optimalRange: "35% - 65%",
      getStatus: (value) => {
        if (value < 35) return { text: "Too Dry", color: "text-accentYellow" };
        if (value > 65)
          return { text: "Too Humid", color: "text-accentYellow" };
        return { text: "Optimal", color: "text-primary" };
      },
    },
    moisture: {
      label: "Soil Moisture",
      unit: "%",
      color: "#4CAF50", // Green color from SeasonalSensorDashboard
      icon: <Waves className="h-5 w-5" />,
      optimalRange: "40% - 70%",
      getStatus: (value) => {
        if (value < 20) return { text: "Low", color: "text-accentYellow" };
        if (value < 40) return { text: "Medium", color: "text-accentYellow" };
        if (value < 70) return { text: "Good", color: "text-primary" };
        return { text: "Excellent", color: "text-darkBlue" };
      },
    },
    temperature: {
      label: "Temperature",
      unit: "°C",
      color: "#F4A900", // Yellow/amber color from SeasonalSensorDashboard
      icon: <Thermometer className="h-5 w-5" />,
      optimalRange: "18°C - 25°C",
      getStatus: (value) => {
        if (value < 18) return { text: "Too Cold", color: "text-darkBlue" };
        if (value > 25) return { text: "Too Hot", color: "text-accentYellow" };
        return { text: "Optimal", color: "text-primary" };
      },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brandWhite/50 to-brandWhite/30 p-6 space-y-8">
      <div className="max-w-[1800px] mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/50 backdrop-blur-sm p-6 rounded-xl border border-brandWhite/50 shadow-md">
          <div>
            <h1 className="text-3xl font-bold font-poppins bg-clip-text text-transparent bg-gradient-to-r from-darkBlue to-primary">
              Smart Irrigation Dashboard
            </h1>
            <p className="text-darkBlue/70 mt-1">
              Real-time monitoring and control of your irrigation system
            </p>
            <div className={`mt-2 text-sm font-medium ${getStatusColor()}`}>
              Status: {statusMessage}
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <span className="text-sm text-darkBlue/70">
              Last updated: {lastUpdated.toLocaleTimeString()}
            </span>
            <button
              onClick={refresh}
              className="bg-white/20 p-2 rounded-full hover:bg-white/40 transition-colors"
            >
              <svg
                className="h-4 w-4 text-darkBlue/70"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                />
              </svg>
            </button>
          </div>
        </div>

        {/* Top Controls */}
        <div className="bg-white/50 backdrop-blur-sm p-6 rounded-xl border border-brandWhite/50 shadow-md">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label
                htmlFor="section-select"
                className="block text-sm font-medium text-darkBlue mb-2"
              >
                Farm Section
              </label>
              <Select
                value={selectedSection}
                onValueChange={(value) => setSelectedSection(value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select section" />
                </SelectTrigger>
                <SelectContent>
                  {farmSections.map((section) => (
                    <SelectItem key={section} value={section}>
                      {section}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-darkBlue mb-2">
                Time Range
              </label>
              <div className="flex rounded-md shadow-sm">
                {timeRanges.map((range) => (
                  <button
                    key={range.value}
                    className={`px-4 py-2 text-sm font-medium ${
                      selectedTimeRange === range.value
                        ? "bg-primary text-white"
                        : "bg-white/50 text-darkBlue hover:bg-white/70"
                    } ${
                      range.value === timeRanges[0].value ? "rounded-l-md" : ""
                    } ${
                      range.value === timeRanges[timeRanges.length - 1].value
                        ? "rounded-r-md"
                        : ""
                    } border border-brandWhite/50`}
                    onClick={() => setSelectedTimeRange(range.value)}
                  >
                    {range.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Get Recommendation Button - Mimicking SeasonalSensorDashboard */}
        <Link
          to="/MetricsDashboard"
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90 rounded-md text-sm font-medium transition-colors"
        >
          <BarChart3 className="h-4 w-4" />
          Get Recommendation
        </Link>

        {/* Sensor Cards - with styled cards from SeasonalSensorDashboard */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Soil Humidity Card */}
          <Card className="w-full bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg hover:shadow-xl transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="flex items-center space-x-3">
                <div
                  className="p-2.5 rounded-xl"
                  style={{
                    backgroundColor: `${sensorConfigs.humidity.color}15`,
                  }}
                >
                  {sensorConfigs.humidity.icon}
                </div>
                <div>
                  <CardTitle className="text-xl font-bold font-poppins">
                    {sensorConfigs.humidity.label}
                  </CardTitle>
                  <CardDescription className="text-sm text-darkBlue/70">
                    Last updated: {lastUpdated.toLocaleTimeString()}
                  </CardDescription>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <div
                  className="text-2xl font-bold font-poppins"
                  style={{ color: sensorConfigs.humidity.color }}
                >
                  {soilHumidity}%
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="h-[200px] w-full flex items-center justify-center">
                  <div
                    className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center border-8"
                    style={{
                      borderColor: `${sensorConfigs.humidity.color}${Math.floor(
                        (soilHumidity / 100) * 255
                      )
                        .toString(16)
                        .padStart(2, "0")}`,
                    }}
                  >
                    <span
                      className="text-3xl font-bold"
                      style={{ color: sensorConfigs.humidity.color }}
                    >
                      {soilHumidity}%
                    </span>
                  </div>
                </div>

                <div className="bg-brandWhite/10 p-4 rounded-xl border border-brandWhite/30">
                  <h4 className="text-lg font-semibold mb-3 flex items-center gap-2 font-poppins text-darkBlue">
                    <BarChart2 className="h-5 w-5 text-darkBlue" />
                    Key Insights
                  </h4>
                  <ul className="space-y-2.5">
                    <li className="text-sm text-darkBlue/80 flex items-start gap-2 font-poppins">
                      <span
                        className="block w-1.5 h-1.5 mt-1.5 rounded-full"
                        style={{
                          backgroundColor: sensorConfigs.humidity.color,
                        }}
                      />
                      Optimal range: {sensorConfigs.humidity.optimalRange}
                    </li>
                    <li className="text-sm text-darkBlue/80 flex items-start gap-2 font-poppins">
                      <span
                        className="block w-1.5 h-1.5 mt-1.5 rounded-full"
                        style={{
                          backgroundColor: sensorConfigs.humidity.color,
                        }}
                      />
                      Status:{" "}
                      <span
                        className={
                          sensorConfigs.humidity.getStatus(soilHumidity).color
                        }
                      >
                        {sensorConfigs.humidity.getStatus(soilHumidity).text}
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Soil Moisture Card */}
          <Card className="w-full bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg hover:shadow-xl transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="flex items-center space-x-3">
                <div
                  className="p-2.5 rounded-xl"
                  style={{
                    backgroundColor: `${sensorConfigs.moisture.color}15`,
                  }}
                >
                  {sensorConfigs.moisture.icon}
                </div>
                <div>
                  <CardTitle className="text-xl font-bold font-poppins">
                    {sensorConfigs.moisture.label}
                  </CardTitle>
                  <CardDescription className="text-sm text-darkBlue/70">
                    Last updated: {lastUpdated.toLocaleTimeString()}
                  </CardDescription>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <div
                  className="text-2xl font-bold font-poppins"
                  style={{ color: sensorConfigs.moisture.color }}
                >
                  {soilMoisture}%
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="h-[200px] w-full flex items-center justify-center">
                  <div
                    className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center border-8"
                    style={{
                      borderColor: `${sensorConfigs.moisture.color}${Math.floor(
                        (soilMoisture / 100) * 255
                      )
                        .toString(16)
                        .padStart(2, "0")}`,
                    }}
                  >
                    <span
                      className="text-3xl font-bold"
                      style={{ color: sensorConfigs.moisture.color }}
                    >
                      {soilMoisture}%
                    </span>
                  </div>
                </div>

                <div className="bg-brandWhite/10 p-4 rounded-xl border border-brandWhite/30">
                  <h4 className="text-lg font-semibold mb-3 flex items-center gap-2 font-poppins text-darkBlue">
                    <BarChart2 className="h-5 w-5 text-darkBlue" />
                    Key Insights
                  </h4>
                  <ul className="space-y-2.5">
                    <li className="text-sm text-darkBlue/80 flex items-start gap-2 font-poppins">
                      <span
                        className="block w-1.5 h-1.5 mt-1.5 rounded-full"
                        style={{
                          backgroundColor: sensorConfigs.moisture.color,
                        }}
                      />
                      Optimal range: {sensorConfigs.moisture.optimalRange}
                    </li>
                    <li className="text-sm text-darkBlue/80 flex items-start gap-2 font-poppins">
                      <span
                        className="block w-1.5 h-1.5 mt-1.5 rounded-full"
                        style={{
                          backgroundColor: sensorConfigs.moisture.color,
                        }}
                      />
                      Status:{" "}
                      <span
                        className={
                          sensorConfigs.moisture.getStatus(soilMoisture).color
                        }
                      >
                        {sensorConfigs.moisture.getStatus(soilMoisture).text}
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Temperature Card */}
          <Card className="w-full bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg hover:shadow-xl transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="flex items-center space-x-3">
                <div
                  className="p-2.5 rounded-xl"
                  style={{
                    backgroundColor: `${sensorConfigs.temperature.color}15`,
                  }}
                >
                  {sensorConfigs.temperature.icon}
                </div>
                <div>
                  <CardTitle className="text-xl font-bold font-poppins">
                    {sensorConfigs.temperature.label}
                  </CardTitle>
                  <CardDescription className="text-sm text-darkBlue/70">
                    Last updated: {lastUpdated.toLocaleTimeString()}
                  </CardDescription>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <div
                  className="text-2xl font-bold font-poppins"
                  style={{ color: sensorConfigs.temperature.color }}
                >
                  {temperature}°C
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="h-[200px] w-full flex items-center justify-center">
                  <div
                    className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center border-8"
                    style={{
                      borderColor: `${
                        sensorConfigs.temperature.color
                      }${Math.floor((temperature / 40) * 255)
                        .toString(16)
                        .padStart(2, "0")}`,
                    }}
                  >
                    <span
                      className="text-3xl font-bold"
                      style={{ color: sensorConfigs.temperature.color }}
                    >
                      {temperature}°C
                    </span>
                  </div>
                </div>

                <div className="bg-brandWhite/10 p-4 rounded-xl border border-brandWhite/30">
                  <h4 className="text-lg font-semibold mb-3 flex items-center gap-2 font-poppins text-darkBlue">
                    <BarChart2 className="h-5 w-5 text-darkBlue" />
                    Key Insights
                  </h4>
                  <ul className="space-y-2.5">
                    <li className="text-sm text-darkBlue/80 flex items-start gap-2 font-poppins">
                      <span
                        className="block w-1.5 h-1.5 mt-1.5 rounded-full"
                        style={{
                          backgroundColor: sensorConfigs.temperature.color,
                        }}
                      />
                      Optimal range: {sensorConfigs.temperature.optimalRange}
                    </li>
                    <li className="text-sm text-darkBlue/80 flex items-start gap-2 font-poppins">
                      <span
                        className="block w-1.5 h-1.5 mt-1.5 rounded-full"
                        style={{
                          backgroundColor: sensorConfigs.temperature.color,
                        }}
                      />
                      Status:{" "}
                      <span
                        className={
                          sensorConfigs.temperature.getStatus(temperature).color
                        }
                      >
                        {sensorConfigs.temperature.getStatus(temperature).text}
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Soil Analysis Trends Chart */}
        <Card className="w-full bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg hover:shadow-xl transition-shadow duration-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl font-bold font-poppins">
              Soil Analysis Trends
            </CardTitle>
            <CardDescription className="text-sm text-darkBlue/70">
              Monitoring changes over {selectedTimeRange} time period
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={moistureData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(139,94,59,0.1)"
                  />
                  <XAxis
                    dataKey="time"
                    stroke="rgba(139,94,59,0.5)"
                    fontSize={12}
                    tickMargin={10}
                  />
                  <YAxis
                    domain={[0, 100]}
                    stroke="rgba(139,94,59,0.5)"
                    fontSize={12}
                    label={{
                      value: "%",
                      position: "insideLeft",
                      angle: -90,
                      dx: -10,
                      style: { fill: "rgba(139,94,59,0.5)" },
                    }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(228,205,167,0.95)",
                      border: "1px solid rgba(139,94,59,0.1)",
                      borderRadius: "8px",
                      boxShadow: "0 4px 6px -1px rgba(139,94,59,0.1)",
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="moisture"
                    name="Moisture"
                    stroke={sensorConfigs.moisture.color}
                    strokeWidth={2.5}
                    dot={false}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="humidity"
                    name="Humidity"
                    stroke={sensorConfigs.humidity.color}
                    strokeWidth={2.5}
                    dot={false}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="temperature"
                    name="Temperature"
                    stroke={sensorConfigs.temperature.color}
                    strokeWidth={2.5}
                    dot={false}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Irrigation Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="w-full bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg hover:shadow-xl transition-shadow duration-200 col-span-1 md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl font-bold font-poppins">
                Irrigation Controls
              </CardTitle>
              <CardDescription className="text-sm text-darkBlue/70">
                Manage irrigation for {selectedSection}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <button
                  onClick={handleStartIrrigation}
                  disabled={isIrrigating}
                  className={`flex items-center ${
                    isIrrigating
                      ? "bg-brandWhite/20 cursor-not-allowed text-darkBlue/40"
                      : "bg-primary hover:bg-primary/90 text-white"
                  } py-3 px-6 rounded-lg transition-colors`}
                >
                  <Droplets className="h-5 w-5 mr-2" />
                  Start Irrigation
                </button>
                <button
                  onClick={handleStopIrrigation}
                  disabled={!isIrrigating}
                  className={`flex items-center ${
                    !isIrrigating
                      ? "bg-brandWhite/20 cursor-not-allowed text-darkBlue/40"
                      : "bg-accentYellow hover:bg-accentYellow/90 text-white"
                  } py-3 px-6 rounded-lg transition-colors`}
                >
                  <X className="h-5 w-5 mr-2" />
                  Stop Irrigation
                </button>
                <button
                  onClick={() => setShowScheduleModal(true)}
                  className="flex items-center bg-primary hover:bg-primary/90 text-white py-3 px-6 rounded-lg transition-colors"
                >
                  <Calendar className="h-5 w-5 mr-2" />
                  Schedule Irrigation
                </button>
              </div>

              {/* Irrigation History */}
              {
                <div className="mt-6">
                  <h3 className="text-lg font-medium text-darkBlue mb-3 flex items-center gap-2">
                    <History className="h-5 w-5" />
                    Irrigation History
                  </h3>
                  <div className="bg-brandWhite/30 rounded-lg border border-brandWhite/50 overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-brandWhite/50">
                        <thead className="bg-brandWhite/50">
                          <tr>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-darkBlue/70 uppercase tracking-wider"
                            >
                              Section
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-darkBlue/70 uppercase tracking-wider"
                            >
                              Date
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-darkBlue/70 uppercase tracking-wider"
                            >
                              Time
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-darkBlue/70 uppercase tracking-wider"
                            >
                              Duration
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white/30 divide-y divide-brandWhite/50">
                          {irrigationHistory.map((record, index) => (
                            <tr
                              key={index}
                              className="hover:bg-brandWhite/40 transition-colors"
                            >
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-darkBlue">
                                {record.section}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-darkBlue/70">
                                {record.date}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-darkBlue/70">
                                {record.time}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-darkBlue/70">
                                {record.duration}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              }
            </CardContent>
          </Card>

          {/* Settings & Recommendations Card */}
          <Card className="w-full bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg hover:shadow-xl transition-shadow duration-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl font-bold font-poppins">
                System Settings
              </CardTitle>
              <CardDescription className="text-sm text-darkBlue/70">
                Customize irrigation parameters
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-darkBlue">
                    Moisture Threshold
                  </label>
                  <div className="flex items-center">
                    <input
                      type="range"
                      min="20"
                      max="80"
                      defaultValue="30"
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <span className="ml-2 text-sm text-darkBlue/70">30%</span>
                  </div>
                  <p className="text-xs text-darkBlue/60">
                    System will trigger irrigation when moisture falls below
                    this threshold
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-darkBlue">
                    Duration
                  </label>
                  <select className="w-full px-3 py-2 text-sm border border-brandWhite/50 rounded-md bg-white/50">
                    <option value="10">10 minutes</option>
                    <option value="20">20 minutes</option>
                    <option selected value="30">
                      30 minutes
                    </option>
                    <option value="45">45 minutes</option>
                    <option value="60">60 minutes</option>
                  </select>
                </div>

                <div className="pt-4">
                  <h4 className="font-medium text-darkBlue mb-2">
                    Recommendations
                  </h4>
                  {soilMoisture < 30 ? (
                    <div className="p-3 bg-accentYellow/10 text-darkBlue border border-accentYellow/30 rounded-md text-sm">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="h-5 w-5 text-accentYellow flex-shrink-0 mt-0.5" />
                        <p>
                          Low soil moisture detected in {selectedSection}.
                          Consider starting irrigation soon to prevent plant
                          stress.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-primary/10 text-darkBlue border border-primary/30 rounded-md text-sm">
                      <div className="flex items-start gap-2">
                        <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                        <p>
                          Soil conditions in {selectedSection} are currently
                          optimal. No irrigation needed at this time.
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                <button className="flex items-center justify-center gap-2 w-full bg-darkBlue hover:bg-darkBlue/90 text-white py-2.5 rounded-lg transition-colors mt-4">
                  <Settings className="h-4 w-4" />
                  Advanced Settings
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Schedule Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setShowScheduleModal(false)}
          ></div>
          <div className="relative bg-white rounded-xl shadow-xl w-full max-w-md p-6 z-10">
            <h3 className="text-xl font-bold font-poppins text-darkBlue mb-4">
              Schedule Irrigation
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-darkBlue mb-1">
                  Select Farm Section
                </label>
                <select className="w-full px-3 py-2 text-sm border border-brandWhite/50 rounded-md bg-white/50">
                  {farmSections.map((section) => (
                    <option
                      key={section}
                      value={section}
                      selected={section === selectedSection}
                    >
                      {section}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-darkBlue mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    className="w-full px-3 py-2 text-sm border border-brandWhite/50 rounded-md bg-white/50"
                    defaultValue={new Date().toISOString().split("T")[0]}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-darkBlue mb-1">
                    Time
                  </label>
                  <input
                    type="time"
                    className="w-full px-3 py-2 text-sm border border-brandWhite/50 rounded-md bg-white/50"
                    defaultValue="06:00"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-darkBlue mb-1">
                  Duration
                </label>
                <select className="w-full px-3 py-2 text-sm border border-brandWhite/50 rounded-md bg-white/50">
                  <option value="10">10 minutes</option>
                  <option value="20">20 minutes</option>
                  <option selected value="30">
                    30 minutes
                  </option>
                  <option value="45">45 minutes</option>
                  <option value="60">60 minutes</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-darkBlue mb-1">
                  Repeat
                </label>
                <select className="w-full px-3 py-2 text-sm border border-brandWhite/50 rounded-md bg-white/50">
                  <option value="once">Once</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="custom">Custom</option>
                </select>
              </div>

              <div className="flex space-x-3 pt-2">
                <button
                  className="flex-1 bg-gray-200 hover:bg-gray-300 text-darkBlue py-2 rounded-lg transition-colors"
                  onClick={() => setShowScheduleModal(false)}
                >
                  Cancel
                </button>
                <button
                  className="flex-1 bg-primary hover:bg-primary/90 text-white py-2 rounded-lg transition-colors"
                  onClick={() => {
                    setShowScheduleModal(false);
                    showNotificationMessage(
                      "Irrigation scheduled successfully!"
                    );
                  }}
                >
                  Schedule
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {showNotification && (
        <div className="fixed bottom-4 right-4 bg-white shadow-lg rounded-lg px-4 py-3 flex items-center gap-3 border-l-4 border-primary animate-slideIn">
          <Check className="h-5 w-5 text-primary" />
          <p className="text-sm text-darkBlue">{notificationMessage}</p>
        </div>
      )}
    </div>
  );
}
