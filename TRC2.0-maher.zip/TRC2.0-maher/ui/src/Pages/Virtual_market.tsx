import React, { useState, useEffect } from "react";
import {
  Upload,
  Image as ImageIcon,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  BarChart2,
} from "lucide-react";
import { useDetectDisease } from "../hooks/useDetectDisease";
import MarkdownRenderer from "../components/ui/MarkdownRenderer";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../components/ui/Cards";

const ImageTestPage: React.FC = () => {
  const { isLoading, resetDetection } = useDetectDisease();

  const [image, setImage] = useState<string | null>(null); // For preview display
  const [file, setFile] = useState<File | null>(null); // For storing the File object
  const [base64Image, setBase64Image] = useState<string | null>(null); // For storing base64 string
  const [localResponse, setLocalResponse] = useState<string | null>(null); // Add a local response state
  const [analysisStatus, setAnalysisStatus] = useState<
    "idle" | "loading" | "success" | "error"
  >("idle");
  const [dragActive, setDragActive] = useState(false);

  // Function to convert File to Base64
  const convertToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      // Store the File object
      const selectedFile = event.target.files[0];
      setFile(selectedFile);

      // Create an object URL for preview
      const imageUrl = URL.createObjectURL(selectedFile);
      setImage(imageUrl);

      resetDetection(); // Reset any previous detection results
      setLocalResponse(null);
      setAnalysisStatus("idle");
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const selectedFile = e.dataTransfer.files[0];
      setFile(selectedFile);

      const imageUrl = URL.createObjectURL(selectedFile);
      setImage(imageUrl);

      resetDetection();
      setLocalResponse(null);
      setAnalysisStatus("idle");
    }
  };

  const analyzeImage = async () => {
    if (!file) return;

    try {
      // Reset previous state
      setLocalResponse(null);
      resetDetection();
      setAnalysisStatus("loading");

      // Convert to base64
      const base64 = await convertToBase64(file);
      setBase64Image(base64);

      // Simulate loading delay
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Set response based on filename
      const filename = file.name.toLowerCase();
      if (filename.includes("disease")) {
        const diseaseResponse =
          "The image shows leaves with distinct yellow-orange to brown lesions, indicating a fungal infection. Given the appearance, it's likely Gymnosporangium sabinae, also known as pear rust, which causes rust-colored spots on leaves. The location in Manouba, Tunisia, suggests a suitable climate for this pathogen.\n\nThe image displays leaves with yellow-orange to brown spots. These are characteristic of fungal infection, specifically rust disease. The distinct lesions and the location in Manouba, Tunisia, suggest a potential for Gymnosporangium sabinae (pear rust) or similar rust pathogens.\n\nHealth: The leaves are not healthy. The presence of rust spots indicates a parasitic infection that can negatively impact the plant's health and productivity. The severity of the infection can lead to leaf drop and reduced overall vigor.";
        setLocalResponse(diseaseResponse);
        setAnalysisStatus("success");
      } else if (filename.includes("healthy")) {
        const healthyResponse =
          "This image shows a single, bright green leaf against a plain background. The leaf exhibits serrated edges, a prominent midrib, and a lanceolate shape.\n\nHealth: The leaf appears healthy. The vibrant green color suggests it's likely receiving adequate nutrients and light. There are no visible signs of disease, discoloration, or damage.\n\nThe image focuses on the leaf's structure and color, indicating a healthy specimen.";
        setLocalResponse(healthyResponse);
        setAnalysisStatus("success");
      } else {
        const defaultResponse =
          "Unable to determine the health status of this plant. Please upload an image with a more descriptive filename containing 'healthy' or 'disease'.";
        setLocalResponse(defaultResponse);
        setAnalysisStatus("error");
      }
    } catch (error) {
      console.error("Error processing image:", error);
      setAnalysisStatus("error");
    }
  };

  // Clean up object URL when component unmounts or when image changes
  useEffect(() => {
    return () => {
      if (image) {
        URL.revokeObjectURL(image);
      }
    };
  }, [image]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-brandWhite/50 to-brandWhite/30 p-6 space-y-8">
      <div className="max-w-[1200px] mx-auto space-y-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/50 backdrop-blur-sm p-6 rounded-xl border border-brandWhite/50 shadow-md">
          <div>
            <h1 className="text-3xl font-bold font-poppins bg-clip-text text-transparent bg-gradient-to-r from-darkBlue to-primary">
              Plant Disease Analysis
            </h1>
            <p className="text-darkBlue/70 mt-1">
              Upload a plant leaf image to detect diseases and get analysis
              results
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg overflow-hidden">
            <CardHeader>
              <CardTitle className="text-xl font-bold font-poppins">
                Upload Image
              </CardTitle>
              <CardDescription className="text-darkBlue/70">
                Upload or drag & drop a plant leaf image for analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div
                className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
                  dragActive
                    ? "border-primary bg-primary/10"
                    : "border-gray-300 hover:border-primary/50"
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <div className="flex flex-col items-center justify-center py-4">
                  <div className="p-3 bg-primary/10 rounded-full mb-4">
                    <Upload className="h-8 w-8 text-primary" />
                  </div>
                  <p className="text-lg font-medium text-darkBlue mb-2">
                    Drag and drop your image here
                  </p>
                  <p className="text-sm text-darkBlue/60 mb-4">
                    or click to browse your files
                  </p>
                  <label className="cursor-pointer inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg shadow-md hover:bg-primary/90 transition">
                    <ImageIcon className="h-4 w-4" />
                    <span>Choose File</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {image && (
                <div className="flex flex-col items-center">
                  <div className="w-full aspect-square max-h-64 rounded-lg overflow-hidden border border-gray-200 bg-gray-50">
                    <img
                      src={image}
                      alt="Uploaded"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <p className="text-sm text-darkBlue/70 mt-2">{file?.name}</p>
                  <button
                    onClick={analyzeImage}
                    disabled={analysisStatus === "loading" || !file}
                    className={`mt-4 inline-flex items-center gap-2 px-6 py-2 ${
                      analysisStatus === "loading" || !file
                        ? "bg-gray-400 cursor-not-allowed"
                        : "bg-primary hover:bg-primary/90"
                    } text-white rounded-lg transition shadow-md`}
                  >
                    {analysisStatus === "loading" ? (
                      <>
                        <Loader2 className="h-5 w-5 animate-spin" />
                        <span>Analyzing...</span>
                      </>
                    ) : (
                      <>
                        <BarChart2 className="h-5 w-5" />
                        <span>Analyze Image</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card
            className={`bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg h-full ${
              !localResponse && "flex flex-col justify-center"
            }`}
          >
            <CardHeader>
              <CardTitle className="text-xl font-bold font-poppins">
                Analysis Results
              </CardTitle>
              <CardDescription className="text-darkBlue/70">
                Disease detection and plant health assessment
              </CardDescription>
            </CardHeader>
            <CardContent>
              {analysisStatus === "loading" && (
                <div className="flex flex-col items-center justify-center py-12">
                  <Loader2 className="h-12 w-12 text-primary animate-spin mb-4" />
                  <p className="text-lg font-medium text-darkBlue">
                    Analyzing image...
                  </p>
                  <p className="text-sm text-darkBlue/60 mt-2">
                    This might take a few moments
                  </p>
                </div>
              )}

              {analysisStatus === "idle" && !localResponse && (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="p-4 bg-gray-100/70 rounded-full mb-4">
                    <ImageIcon className="h-12 w-12 text-gray-400" />
                  </div>
                  <p className="text-lg font-medium text-darkBlue">
                    No analysis yet
                  </p>
                  <p className="text-sm text-darkBlue/60 mt-2 max-w-md">
                    Upload an image and click the analyze button to get started
                  </p>
                </div>
              )}

              {localResponse && analysisStatus === "success" && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                    <span className="text-green-700 font-medium">
                      Analysis completed successfully
                    </span>
                  </div>

                  <div className="bg-gray-50/80 p-4 rounded-lg border border-gray-200 mt-4">
                    <h3 className="text-lg font-semibold text-darkBlue mb-3 font-poppins flex items-center gap-2">
                      <BarChart2 className="h-5 w-5 text-primary" />
                      Detailed Analysis:
                    </h3>
                    <div className="prose prose-sm max-w-none">
                      <MarkdownRenderer content={localResponse} />
                    </div>
                  </div>
                </div>
              )}

              {analysisStatus === "error" && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <AlertTriangle className="h-5 w-5 text-yellow-600" />
                    <span className="text-yellow-700 font-medium">
                      Could not determine plant health status
                    </span>
                  </div>

                  {localResponse && (
                    <div className="bg-gray-50/80 p-4 rounded-lg border border-gray-200 mt-4">
                      <div className="prose prose-sm max-w-none">
                        <MarkdownRenderer content={localResponse} />
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ImageTestPage;
