import React, { useState, useMemo, useEffect } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "../components/ui/Cards";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/Selects";
import {
  Activity,
  Droplets,
  Leaf,
  Thermometer,
  BarChart2,
  BarChart3,
} from "lucide-react";
import seasonalData from "../data/seasonal_sensor_data.json";
import RealTimeMeasurements from "./RealTimeMeasurements";
import { Link } from "react-router-dom";

type SensorData = {
  timestamp: string;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  temperature: number;
  humidity: number;
  pH_Value: number;
  rainfall: number;
};

type SensorConfig = {
  label: string;
  unit: string;
  color: string;
  domain: [number, number];
  icon: React.ReactNode;
  insights: (data: SensorData[]) => string[];
};

const sensorConfigs: Record<keyof Omit<SensorData, "timestamp">, SensorConfig> =
  {
    nitrogen: {
      label: "Nitrogen Level",
      unit: "%",
      color: "#4CAF50",
      domain: [0, 100],
      icon: <Leaf className="h-5 w-5" />,
      insights: (data) => {
        // Safety check if data is empty
        if (!data.length) return ["No data available"];

        const currentValue = data[data.length - 1]?.nitrogen;
        const average =
          data.reduce((sum, d) => sum + d.nitrogen, 0) / data.length;

        return [
          `Current Level: ${currentValue?.toFixed(2) || "N/A"}%`,
          `30-Day Average: ${average?.toFixed(2) || "N/A"}%`,
          `Optimal Range: 20-50% for most crops`,
          `Status: ${
            currentValue > 50 ? "Above" : currentValue < 20 ? "Below" : "Within"
          } optimal range`,
        ];
      },
    },
    phosphorus: {
      label: "Phosphorus Level",
      unit: "%",
      color: "#8B5E3B",
      domain: [0, 50],
      icon: <Leaf className="h-5 w-5" />,
      insights: (data) => {
        if (!data.length) return ["No data available"];

        const currentValue = data[data.length - 1]?.phosphorus;
        const average =
          data.reduce((sum, d) => sum + d.phosphorus, 0) / data.length;

        return [
          `Current Level: ${currentValue?.toFixed(2) || "N/A"}%`,
          `30-Day Average: ${average?.toFixed(2) || "N/A"}%`,
          `Optimal Range: 10-50%`,
          `Status: ${
            currentValue > 30 ? "High" : currentValue < 10 ? "Low" : "Optimal"
          }`,
        ];
      },
    },
    potassium: {
      label: "Potassium Level",
      unit: "%",
      color: "#F4A900",
      domain: [0, 100],
      icon: <Leaf className="h-5 w-5" />,
      insights: (data) => {
        if (!data.length) return ["No data available"];

        const currentValue = data[data.length - 1]?.potassium;
        const firstValue = data[0]?.potassium;
        const average =
          data.reduce((sum, d) => sum + d.potassium, 0) / data.length;

        return [
          `Current Level: ${currentValue?.toFixed(2) || "N/A"}%`,
          `30-Day Average: ${average?.toFixed(2) || "N/A"}%`,
          `Optimal Range: 40-80%`,
          `Trend: ${
            currentValue > firstValue ? "↗ Increasing" : "↘ Decreasing"
          }`,
        ];
      },
    },
    temperature: {
      label: "Temperature",
      unit: "°C",
      color: "#F4A900",
      domain: [0, 50],
      icon: <Thermometer className="h-5 w-5" />,
      insights: (data) => {
        if (!data.length) return ["No data available"];

        const currentValue = data[data.length - 1]?.temperature;
        const minTemp = Math.min(...data.map((d) => d.temperature));
        const maxTemp = Math.max(...data.map((d) => d.temperature));

        return [
          `Current: ${currentValue?.toFixed(1) || "N/A"}°C`,
          `Daily Range: ${minTemp?.toFixed(1) || "N/A"}°C - ${
            maxTemp?.toFixed(1) || "N/A"
          }°C`,
          `Optimal: 18-25°C for most crops`,
          `Status: ${
            currentValue > 25
              ? "⚠️ High"
              : currentValue < 18
              ? "⚠️ Low"
              : "✓ Optimal"
          }`,
        ];
      },
    },
    humidity: {
      label: "Humidity Level",
      unit: "%",
      color: "#5DADE2",
      domain: [0, 100],
      icon: <Droplets className="h-5 w-5" />,
      insights: (data) => {
        if (!data.length) return ["No data available"];

        const currentValue = data[data.length - 1]?.humidity;
        const average =
          data.reduce((sum, d) => sum + d.humidity, 0) / data.length;

        return [
          `Current Level: ${currentValue?.toFixed(1) || "N/A"}%`,
          `Average: ${average?.toFixed(1) || "N/A"}%`,
          `Ideal Range: 40-60%`,
          `Risk Level: ${
            currentValue > 70
              ? "High (Disease)"
              : currentValue < 30
              ? "High (Drought)"
              : "Low"
          }`,
        ];
      },
    },
    pH_Value: {
      label: "Soil pH",
      unit: "pH",
      color: "#8B5E3B",
      domain: [0, 14],
      icon: <Activity className="h-5 w-5" />,
      insights: (data) => {
        if (!data.length) return ["No data available"];

        const currentValue = data[data.length - 1]?.pH_Value;
        const average =
          data.reduce((sum, d) => sum + d.pH_Value, 0) / data.length;

        return [
          `Current pH: ${currentValue?.toFixed(1) || "N/A"}`,
          `30-Day Average: ${average?.toFixed(1) || "N/A"}`,
          `Optimal: 6.0-7.0 pH`,
          `Soil Type: ${
            currentValue > 7
              ? "Alkaline"
              : currentValue < 6
              ? "Acidic"
              : "Neutral"
          }`,
        ];
      },
    },
    rainfall: {
      label: "Rainfall",
      unit: "mm",
      color: "#5DADE2",
      domain: [0, 100],
      icon: <Droplets className="h-5 w-5" />,
      insights: (data) => {
        if (!data.length) return ["No data available"];

        const currentValue = data[data.length - 1]?.rainfall;
        const totalRainfall = data.reduce((sum, d) => sum + d.rainfall, 0);
        const average = totalRainfall / data.length;

        return [
          `Last Reading: ${currentValue?.toFixed(1) || "N/A"} mm`,
          `Monthly Total: ${totalRainfall?.toFixed(1) || "N/A"} mm`,
          `Daily Average: ${average?.toFixed(1) || "N/A"} mm`,
          `Trend: ${
            currentValue > 30
              ? "Heavy"
              : currentValue > 10
              ? "Moderate"
              : "Light"
          }`,
        ];
      },
    },
  };

const filterOptions = [
  { value: "all", label: "All Data" },
  { value: "lastMonth", label: "Last 30 Days" },
  { value: "lastQuarter", label: "Last Quarter" },
] as const;

type FilterOption = (typeof filterOptions)[number]["value"];

const SeasonalSensorDashboard: React.FC = () => {
  const [data] = useState<SensorData[]>(seasonalData);
  const [selectedFilter, setSelectedFilter] = useState<FilterOption>("all");
  const [realTimeData, setRealTimeData] = useState<SensorData | null>(null);
  const [previousRealTimeData, setPreviousRealTimeData] =
    useState<SensorData | null>(null);

  useEffect(() => {
    const initialData: SensorData = {
      timestamp: new Date().toISOString(),
      nitrogen: 40 + Math.random() * 20,
      phosphorus: 20 + Math.random() * 10,
      potassium: 50 + Math.random() * 20,
      temperature: 22 + Math.random() * 5,
      humidity: 50 + Math.random() * 20,
      pH_Value: 6 + Math.random() * 2,
      rainfall: 20 + Math.random() * 10,
    };

    setRealTimeData(initialData);

    const generateSmallChange = (current: number, max: number) => {
      const maxChange = max * 0.02;
      const change = (Math.random() - 0.5) * maxChange;
      return Math.max(0, Math.min(max, current + change));
    };

    const interval = setInterval(() => {
      if (realTimeData) {
        setPreviousRealTimeData(realTimeData);
        setRealTimeData((prev) => {
          if (!prev) return null;
          return {
            timestamp: new Date().toISOString(),
            nitrogen: generateSmallChange(prev.nitrogen, 100),
            phosphorus: generateSmallChange(prev.phosphorus, 50),
            potassium: generateSmallChange(prev.potassium, 100),
            temperature: generateSmallChange(prev.temperature, 35),
            humidity: generateSmallChange(prev.humidity, 100),
            pH_Value: generateSmallChange(prev.pH_Value, 14),
            rainfall: generateSmallChange(prev.rainfall, 50),
          };
        });
      }
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const filteredData = useMemo(() => {
    if (!data || !data.length) return [];

    const now = new Date();
    switch (selectedFilter) {
      case "lastMonth":
        return data.filter((d) => {
          const dataDate = new Date(d.timestamp);
          const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
          return dataDate >= monthAgo;
        });
      case "lastQuarter":
        return data.filter((d) => {
          const dataDate = new Date(d.timestamp);
          const quarterAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
          return dataDate >= quarterAgo;
        });
      default:
        return data;
    }
  }, [data, selectedFilter]);

  const renderSensorChart = (sensorKey: keyof typeof sensorConfigs) => {
    const config = sensorConfigs[sensorKey];

    // Safety checks for when filteredData might be empty
    const currentValue =
      filteredData.length > 0
        ? filteredData[filteredData.length - 1]?.[sensorKey]
        : null;
    const previousValue =
      filteredData.length > 1
        ? filteredData[filteredData.length - 2]?.[sensorKey]
        : null;
    const percentageChange =
      previousValue && currentValue
        ? ((currentValue - previousValue) / previousValue) * 100
        : 0;

    return (
      <Card
        key={sensorKey}
        className="w-full bg-white/50 backdrop-blur-sm border border-brandWhite/50 shadow-lg hover:shadow-xl transition-shadow duration-200"
      >
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div className="flex items-center space-x-3">
            <div
              className="p-2.5 rounded-xl"
              style={{ backgroundColor: `${config.color}15` }}
            >
              {React.cloneElement(config.icon as React.ReactElement, {
                className: `h-6 w-6`,
                style: { color: config.color },
              })}
            </div>
            <div>
              <CardTitle className="text-xl font-bold font-poppins">
                {config.label}
              </CardTitle>
              <CardDescription className="text-sm text-darkBlue/70">
                {filteredData.length > 0 ? (
                  <>
                    Last updated:{" "}
                    {new Date(
                      filteredData[filteredData.length - 1]?.timestamp
                    ).toLocaleTimeString()}
                  </>
                ) : (
                  "No data available"
                )}
              </CardDescription>
            </div>
          </div>
          <div className="flex flex-col items-end">
            <div
              className="text-2xl font-bold font-poppins"
              style={{ color: config.color }}
            >
              {currentValue !== null
                ? `${currentValue.toFixed(1)}${config.unit}`
                : "N/A"}
            </div>
            {percentageChange !== 0 && (
              <div
                className={`text-sm ${
                  percentageChange > 0 ? "text-primary" : "text-accentYellow"
                }`}
              >
                {percentageChange > 0 ? "↑" : "↓"}{" "}
                {Math.abs(percentageChange).toFixed(1)}%
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="h-[300px] w-full">
              {filteredData.length > 0 ? (
                <ResponsiveContainer>
                  <LineChart data={filteredData}>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="rgba(139,94,59,0.1)"
                    />
                    <XAxis
                      dataKey="timestamp"
                      tickFormatter={(timestamp) =>
                        new Date(timestamp).toLocaleDateString()
                      }
                      stroke="rgba(139,94,59,0.5)"
                      fontSize={12}
                    />
                    <YAxis
                      label={{
                        value: config.unit,
                        angle: -90,
                        position: "insideLeft",
                        style: { fill: "rgba(139,94,59,0.5)" },
                      }}
                      domain={config.domain}
                      stroke="rgba(139,94,59,0.5)"
                      fontSize={12}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(228,205,167,0.95)",
                        border: "1px solid rgba(139,94,59,0.1)",
                        borderRadius: "8px",
                        boxShadow: "0 4px 6px -1px rgba(139,94,59,0.1)",
                      }}
                      labelFormatter={(timestamp) =>
                        new Date(timestamp).toLocaleString()
                      }
                      formatter={(value) => [
                        `${value} ${config.unit}`,
                        config.label,
                      ]}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey={sensorKey}
                      stroke={config.color}
                      strokeWidth={2.5}
                      dot={false}
                      activeDot={{ r: 6, strokeWidth: 0 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full w-full flex items-center justify-center">
                  <p className="text-darkBlue/70">
                    No data available for the selected time period
                  </p>
                </div>
              )}
            </div>

            <div className="bg-brandWhite/10 p-4 rounded-xl border border-brandWhite/30">
              <h4 className="text-lg font-semibold mb-3 flex items-center gap-2 font-poppins text-darkBlue">
                <BarChart2 className="h-5 w-5 text-darkBlue" />
                Key Insights
              </h4>
              <ul className="space-y-2.5">
                {config.insights(filteredData).map((insight, index) => (
                  <li
                    key={index}
                    className="text-sm text-darkBlue/80 flex items-start gap-2 font-poppins"
                  >
                    <span
                      className="block w-1.5 h-1.5 mt-1.5 rounded-full"
                      style={{ backgroundColor: config.color }}
                    />
                    {insight}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brandWhite/50 to-brandWhite/30 p-6 space-y-8">
      <div className="max-w-[1800px] mx-auto space-y-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/50 backdrop-blur-sm p-6 rounded-xl border border-brandWhite/50 shadow-md">
          <div>
            <h1 className="text-3xl font-bold font-poppins bg-clip-text text-transparent bg-gradient-to-r from-darkBlue to-primary">
              Seasonal Sensor Dashboard
            </h1>
            <p className="text-darkBlue/70 mt-1">
              Real-time monitoring and analysis of environmental conditions
            </p>
          </div>

          <div className="w-full sm:w-[200px]">
            <Select
              value={selectedFilter}
              onValueChange={(value: FilterOption) => setSelectedFilter(value)}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Filter Data" />
              </SelectTrigger>
              <SelectContent>
                {filterOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <Link
          to="/MetricsDashboard"
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90 rounded-md text-sm font-medium transition-colors"
        >
          <BarChart3 className="h-4 w-4" />
          Get Recommendation
        </Link>

        {realTimeData && (
          <RealTimeMeasurements
            data={realTimeData}
            previousData={previousRealTimeData || undefined}
          />
        )}

        {filteredData.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-6">
            {Object.keys(sensorConfigs).map((sensorKey) =>
              renderSensorChart(sensorKey as keyof typeof sensorConfigs)
            )}
          </div>
        ) : (
          <div className="bg-white/50 backdrop-blur-sm p-8 rounded-xl border border-brandWhite/50 shadow-md text-center">
            <p className="text-xl text-darkBlue">
              No data available for the selected time period.
            </p>
            <p className="text-darkBlue/70 mt-2">
              Try selecting a different time filter or check your data source.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SeasonalSensorDashboard;
