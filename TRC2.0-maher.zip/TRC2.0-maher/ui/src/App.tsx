import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import ContactUs from "./Pages/ContactUs";
import Dashboard from "./Pages/Dashboard";
import Interactive from "./Pages/Interactive";
import { Home } from "./Pages/Home";
import Notification from "./Pages/Notification";
import Water_management from "./Pages/Dashboard_récapitulatif";
import { Layout } from "./layout/Layout";
import { Missing } from "./Pages/Missing";
import Virtual_market from "./Pages/Virtual_market";
import MyPage from "./Pages/MyPage";
import MetricsDashboard from "./Pages/MetricsDashboard";
import SmartIrrigationDashboard from "./Pages/SmartIrrigationDashboard";
import BlockchainMarket from "./Pages/BlockchainMarket";
import RealTimeMeasurements from "./Pages/RealTimeMeasurements";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      {
        path: "/",
        element: <Home />,
      },
      {
        path: "/ContactUs",
        element: <ContactUs />,
      },
      {
        path: "/",
        children: [
          {
            path: "/Notification",
            element: <Notification />,
          },
          {
            path: "/Dashboard",
            element: <Dashboard />,
          },
          {
            path: "/Water_management",
            element: <Water_management />,
          },
          {
            path: "/manage-water",
            element: <SmartIrrigationDashboard />,
          },
          {
            path: "/Virtual_market",
            element: <Virtual_market />,
          },
          {
            path: "/Interactive",
            element: <Interactive />,
          },
          {
            path: "/MetricsDashboard",
            element: <MetricsDashboard />,
          },
          {
            path: "/blockchain-market",
            element: <BlockchainMarket />,
          },
          {
            path: "/test",
            element: <MyPage />,
          },
        ],
      },
    ],
  },
  {
    path: "*",
    element: <Missing />,
  },
]);

const App = () => {
  return <RouterProvider router={router} />;
};

export { App };
