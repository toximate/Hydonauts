import React from "react";
import { Outlet } from "react-router-dom";
import Navbar from "../components/Navbar/Navbar";
import Footer from "../components/Footer/Footer";
import GeminiChat from "../components/GeminiChat";

const Layout = () => {
  return (
    <>
      <Navbar />
      <Outlet />
      <Footer />
      <GeminiChat />
    </>
  );
};

export { Layout };
