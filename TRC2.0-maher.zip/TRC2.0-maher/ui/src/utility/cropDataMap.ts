type CropData = {
    co2Absorbed: string;
    o2Released: string;
};

const cropDataMap: Record<string, CropData> = {
    "Chickpea": { co2Absorbed: "1.4 – 1.8", o2Released: "1.0 – 1.3" },
    "Maize (Corn)": { co2Absorbed: "1.6 – 2.2", o2Released: "1.2 – 1.5" },
    "Kidney Beans": { co2Absorbed: "1.5 – 2.0", o2Released: "1.1 – 1.4" },
    "Pigeon Peas": { co2Absorbed: "1.3 – 1.7", o2Released: "0.9 – 1.2" },
    "Moth Beans": { co2Absorbed: "1.2 – 1.6", o2Released: "0.8 – 1.1" },
    "Mung Bean": { co2Absorbed: "1.3 – 1.7", o2Released: "1.0 – 1.2" },
    "Black Gram": { co2Absorbed: "1.4 – 1.9", o2Released: "1.1 – 1.3" },
    "Lentil": { co2Absorbed: "1.5 – 2.0", o2Released: "1.1 – 1.4" },
    "Pomegranate": { co2Absorbed: "1.8 – 2.5", o2Released: "1.3 – 1.8" },
    "Banana": { co2Absorbed: "1.9 – 2.6", o2Released: "1.4 – 1.9" },
    "Mango": { co2Absorbed: "2.0 – 2.8", o2Released: "1.5 – 2.0" },
    "Grapes": { co2Absorbed: "1.6 – 2.2", o2Released: "1.2 – 1.6" },
    "Watermelon": { co2Absorbed: "1.7 – 2.4", o2Released: "1.3 – 1.7" },
    "Muskmelon": { co2Absorbed: "1.6 – 2.3", o2Released: "1.2 – 1.6" },
    "Apple": { co2Absorbed: "2.0 – 2.7", o2Released: "1.5 – 2.0" },
    "Orange": { co2Absorbed: "1.8 – 2.5", o2Released: "1.4 – 1.8" },
    "Papaya": { co2Absorbed: "1.7 – 2.3", o2Released: "1.3 – 1.7" },
    "Coconut": { co2Absorbed: "1.8 – 2.4", o2Released: "1.4 – 1.9" },
    "Cotton": { co2Absorbed: "1.5 – 2.1", o2Released: "1.1 – 1.5" },
    "Jute": { co2Absorbed: "1.6 – 2.3", o2Released: "1.2 – 1.7" },
    "Coffee": { co2Absorbed: "1.9 – 2.7", o2Released: "1.4 – 2.0" },
    "MungBean": { co2Absorbed: "1.3 – 1.7", o2Released: "1.0 – 1.2" },
};

function getCropData(cropName: string): CropData | null {
    return cropDataMap[cropName] || null;
}

export { cropDataMap, getCropData };