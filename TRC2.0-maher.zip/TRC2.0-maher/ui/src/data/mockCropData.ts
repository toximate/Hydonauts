export interface CropRecommendation {
    crop: string;
    explanation: string;
    bestPractices: string[];
    videoUrl: string;
}

export const mockCropRecommendations: Record<string, CropRecommendation> = {
    default: {
        crop: "Rice",
        explanation:
            "Based on the soil properties and climate conditions, rice is recommended as it thrives in moderate nitrogen levels and high water availability.",
        bestPractices: [
            "Maintain standing water of 2-5 cm during the growing season",
            "Apply fertilizers in split doses",
            "Manage weeds regularly, especially in the early stages",
            "Monitor for pests like stem borers and leaf folders",
            "Drain the field 10-15 days before harvesting",
        ],
        videoUrl: "https://www.youtube.com/embed/rMbBWrxDwuk",
    },
    highNitrogen: {
        crop: "Maize",
        explanation:
            "The high nitrogen content in your soil makes maize an ideal crop. Maize requires nitrogen-rich soil for optimal stalk development and yield.",
        bestPractices: [
            "Space plants 60-75 cm between rows and 20-25 cm within rows",
            "Ensure adequate irrigation, especially during tasseling and silking stages",
            "Apply potassium fertilizer to balance the high nitrogen levels",
            "Monitor for corn borers and armyworms",
            "Harvest when kernels become hard and glazed",
        ],
        videoUrl: "https://www.youtube.com/embed/0aZnkaArnvY",
    },
    acidicSoil: {
        crop: "Potato",
        explanation:
            "Your soil's pH level is slightly acidic which is perfect for potato cultivation. Potatoes thrive in well-drained, slightly acidic soils with pH 5.0-6.5.",
        bestPractices: [
            "Use certified disease-free seed potatoes",
            "Plant tubers 10 cm deep and 30 cm apart",
            "Hill the soil around plants as they grow",
            "Maintain consistent soil moisture",
            "Watch for late blight and Colorado potato beetles",
        ],
        videoUrl: "https://www.youtube.com/embed/ThePZ3Exr5U",
    },
    dryConditions: {
        crop: "Chickpea",
        explanation:
            "The lower humidity and rainfall values indicate drier conditions suitable for chickpea cultivation. Chickpeas are drought-tolerant and perform well in these conditions.",
        bestPractices: [
            "Sow seeds 7-10 cm apart and 5-7 cm deep",
            "Apply rhizobium inoculant to seeds before planting",
            "Provide minimal irrigation at flowering and pod formation stages",
            "Control weeds during early growth stages",
            "Monitor for pod borers during the flowering stage",
        ],
        videoUrl: "https://www.youtube.com/embed/zGQMpDDX5MA",
    },
    balancedNutrients: {
        crop: "Wheat",
        explanation:
            "The balanced NPK ratio in your soil makes it ideal for wheat cultivation. Wheat requires moderate levels of all three major nutrients.",
        bestPractices: [
            "Sow seeds at 3-5 cm depth with proper row spacing",
            "Apply phosphorus fertilizer at planting time",
            "Top dress with nitrogen at tillering stage",
            "Irrigate at critical growth stages: crown root initiation, tillering, and grain filling",
            "Monitor for rust diseases and aphids",
        ],
        videoUrl: "https://www.youtube.com/embed/JgBq8Hf8MUA",
    },
};
