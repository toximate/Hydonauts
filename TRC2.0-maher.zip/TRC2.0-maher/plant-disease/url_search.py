import requests

def fetch_google_results(plant_name,format):
    api_key = "AIzaSyD01yIi1gTF6CXQPS-hRmBsDnwKjwxeaNY"
    cse_id = "d242826b29d6d48ca"
    if format == "article":
        query = f"how to plant {plant_name} articles"
    else:
        query = f"how to plant {plant_name} youtube video"
    url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "q": query,
        "key": api_key,
        "cx": cse_id,
        "num": 1  # Max number = 5 (default) results per request
    }

    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        results = response.json()
        return {"url" : [item["link"] for item in results.get("items", [])]}
    except Exception as e:
        print(f"API Error: {e}")
        return {"url" : []}




