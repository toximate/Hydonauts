import pandas as pd
import google.generativeai as genai  # Make sure you have set up Gemini API

def statistical_analysis_report(metrics_dict):
    genai.configure(api_key="AIzaSyCvqg45SOpzb3cOvdEOk0cXMpTng8--4qk")
    
    model = genai.GenerativeModel("gemini-2.0-flash")

    # Input Validation
    if not isinstance(metrics_dict, dict):
        return "Error: 'metrics_dict' must be a dictionary."

    # Constructing the Prompt for LLM
    prompt = (f"You are an expert data analyst with a strong background in data interpretation and inferencing, specializing in agricultural science. "
          f"Given the following key metrics: \n"
          f"- **Mann-Kendall Trend Test:** {metrics_dict.get('trend_stat')}, p-value: {metrics_dict.get('p_value')}\n"
          f"- **Lag-1 Autocorrelation:** {metrics_dict.get('ACF_value')}\n"
          f"- **Cross-Correlation (Rainfall vs. Humidity):** Lag {metrics_dict.get('lag')}, Correlation {metrics_dict.get('correlation')}\n"
          f"- **Nutrient Balance Ratio (N:P:K):** {metrics_dict.get('npk_ratio')}\n"
          f"- **Growing Degree Days (GDD):** {metrics_dict.get('gdd')}\n\n"
          
          f"Provide a two-section report in **clear, concise bullet points**, offering insights backed by logical reasoning and data interpretation:\n\n"
          f"the text should be under 500 words.\n\n"
          f"1. **Insightful Analysis:**\n"
          f"- Analyze each metric individually, explaining what it reveals about soil health, climate patterns, and crop performance.\n"
          f"- Highlight significant trends, anomalies, or risks, connecting findings to real-world agricultural outcomes.\n"
          f"- Justify inferences with reasoning grounded in data analysis principles.\n\n"
          
          f"2. **Actionable Recommendations:**\n"
          f"- Suggest evidence-based strategies to improve sustainability, control pollution, and optimize nutrient management.\n"
          f"- Prioritize recommendations with the highest potential impact on productivity and environmental health.\n"
          f"- Ensure suggestions are practical and data-driven, addressing specific insights derived from the metrics.")


    # Simulating LLM Response (Placeholder)
    response = model.generate_content(prompt)
    
    return {"response": response.text}



