from flask import Flask, request, jsonify
from adaptability_service import AR_ai_agent
from inference_logic import statistical_analysis_report
from bot_logic import get_response
from url_search import fetch_google_results
from flask_cors import CORS


app = Flask(__name__)
CORS(app)


@app.route('/report', methods=['POST'])
def ai_agent():
    if not request.is_json:
        return jsonify({"error": "Invalid input, JSON expected."}), 400

    data = request.get_json()

    plant_name = data.get('plant_name')
    metrics = data.get('metrics')

    if not plant_name or not metrics:
        return jsonify({"error": "Missing 'plant_name' or 'metrics' field."}), 400

    try:
        result = AR_ai_agent(plant_name, metrics)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/url', methods=['POST'])
def url():
    if not request.is_json:
        return jsonify({"error": "Invalid input, JSON expected."}), 400

    data = request.get_json()

    plant_name = data.get('plant_name')
    format = data.get('format')

    if not plant_name or not format:
        return jsonify({"error": "Missing 'plant_name' or 'format' field."}), 400

    try:
        result = fetch_google_results(plant_name, format)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/inference', methods=['POST'])
def inference():
    if not request.is_json:
        return jsonify({"error": "Invalid input, JSON expected."}), 400

    data = request.get_json()

    metrics_dict  = data.get('metrics_dict')
    

    if not metrics_dict :
        return jsonify({"error": "Missing 'metrics_dict' field."}), 400

    try:
        result = statistical_analysis_report(metrics_dict)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/chat', methods=['POST'])
def chat():
    if not request.is_json:
        return jsonify({"error": "Invalid input, JSON expected."}), 400

    data = request.get_json()

    query = data.get('query')

    if not query:
        return jsonify({"error": "Missing 'query' field."}), 400

    try:
        result = get_response(query)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=8080)