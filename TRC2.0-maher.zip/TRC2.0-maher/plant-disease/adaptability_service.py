import pandas as pd
import google.generativeai as genai  # Make sure you have set up Gemini API


def adaptability_explanation(plant_name, metrics):
    genai.configure(api_key="AIzaSyCvqg45SOpzb3cOvdEOk0cXMpTng8--4qk")
    
    model = genai.GenerativeModel("gemini-2.0-flash")

    # Input Validation
    if not isinstance(plant_name, str) or not plant_name.strip():
        return "Error: 'plant_name' must be a non-empty string."
    
    if not isinstance(metrics, dict):
        return "Error: 'metrics' must be a dictionary."

    # Constructing the Prompt for LLM
    prompt = (f"Given the plant name '{plant_name}' and the following soil and environmental metrics: "
          f"Nitrogen: {metrics.get('Nitrogen')} ppm, "
          f"Phosphorus: {metrics.get('Phosphorus')} ppm, "
          f"Potassium: {metrics.get('Potassium')} ppm, "
          f"Temperature: {metrics.get('Temperature')}°C, "
          f"Humidity: {metrics.get('Humidity')}%, "
          f"pH: {metrics.get('pH_Value')}, "
          f"Rainfall: {metrics.get('Rainfall')} mm, "
          f"provide a detailed yet concise evaluation of the plant's adaptability and suitability to these conditions. "
          f"the text should be under 800 words.\n\n"
          f"Explain how each soil and environmental factor influences the crop's growth, yield potential, and overall health. "
          f"Discuss the interaction between nutrient availability, pH balance, and climate variables, providing scientifically sound reasoning. "
          f"Justify why this plant is either optimal or suboptimal for the given conditions, "
          f"highlighting how these factors align with or challenge the plant's physiological needs.")


    # Simulating LLM Response 
    response = model.generate_content(prompt)
    
    return {"explanation": response.text}




def bio_practices_recommendation(plant_name, explanation_text):
    genai.configure(api_key="AIzaSyCvqg45SOpzb3cOvdEOk0cXMpTng8--4qk")
    
    model = genai.GenerativeModel("gemini-2.0-flash")

    # Input Validation
    if not isinstance(plant_name, str) or not plant_name.strip():
        return "Error: 'plant_name' must be a non-empty string."
    
    if not isinstance(explanation_text, str) or not explanation_text.strip():
        return "Error: 'explanation_text' must be a non-empty string."

    # Constructing the Prompt for LLM
    prompt = (f"Given the plant '{plant_name}' and the following soil analysis: {explanation_text}, "
              f"write a well-structured, two-paragraph response tailored to the conditions described. "
              f"the text should be under 500 words.\n\n"
              f"In the first paragraph, recommend specific, sustainable agricultural practices, including eco-friendly "
              f"approaches to planting, irrigation, and soil management, emphasizing adaptation to the given soil conditions. "
              f"In the second paragraph, suggest targeted biological practices to improve soil productivity by addressing "
              f"nutrient deficiencies, enhancing microbial health, and promoting long-term sustainability while minimizing "
          f"environmental pollution. Provide practical, science-based solutions with clear justifications.")

    # Simulating LLM Response (Placeholder)
    response = model.generate_content(prompt)
    
    return {"recommendations": response.text}


def AR_ai_agent(plant_name, metrics):
    explanation = adaptability_explanation(plant_name, metrics)
    explanation_text = explanation["explanation"]
    recommendations = bio_practices_recommendation(plant_name, explanation_text)
    return {"explanation": explanation_text, "recommendations": recommendations["recommendations"]}




