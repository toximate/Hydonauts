import pandas as pd
import google.generativeai as genai  # Make sure you have set up Gemini API

def get_response(query):
    genai.configure(api_key="AIzaSyCvqg45SOpzb3cOvdEOk0cXMpTng8--4qk")
    
    model = genai.GenerativeModel("gemini-2.0-flash")

    # Input Validation
    if not query:
        return "Error: 'query' must be a dictionary."

    # Constructing the Prompt for LLM
    prompt = (f"You are an expert in agriculture with deep knowledge of sustainable farming, soil science, and crop management. "
          f"Given the following query: {query}, provide an *informative and concise* response, focusing on actionable insights "

          f"- the response should be under 50 words.\n\n"
          f"If the query is *not related to agriculture*, respond with: "
          f"'Sorry, I cannot provide you with this information.'")



    # Simulating LLM Response (Placeholder)
    response = model.generate_content(prompt)
    
    return {"response": response.text}

print("test ",get_response("tell me about the benefits of using organic fertilizers"))